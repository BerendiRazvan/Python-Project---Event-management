from domainApp.domain import Evenimente,Persoane,Nume,DTO_Rapoarte
from errorsApp.errors import ValidError
import datetime 
import random
import string



class ServiceEvent:
    """
    Clasa pentru Service EVENIMENTE
    """
    def __init__(self,validareEvent, repoEvent, repoInscrieri):
        self.__validareEvent = validareEvent
        self.__repoEvent = repoEvent
        self.__repoInscrieri = repoInscrieri
    
    def service_getALL_Events(self):
        """
        Returneaza toate evenimentele
        """
        return self.__repoEvent.get_AllEvents()
    
    def service_adaugareEvent(self,idE,data,durata,descriere):
        """
        Adauga eveniment nou in lista de evenimente
        Returneaza 1 -daca s-a realizar adaugarea
        Returneaza 0 -daca nu exista
        """
        ok=0
        try:
            self.__validareEvent.verif_allCRT_event(self.__repoEvent.get_AllEvents(), idE, data, durata, descriere)
            e=Evenimente(idE, data, durata, descriere)
            self.__validareEvent.validare_event(e)
            self.__repoEvent.add_Event(e)
        except ValidError as ve:
            #print(ve) 
            ok=1
        
        if ok==0:
            return 1
        else:
            return 0
    
    def service_stregereEvent(self,idE):
        """
        Sterge eveniment din lista de evenimente
        Returneaza 0 -daca s-a efectuat
        Returneaza 1 -daca nu s-a efectuat
        Returneaza 2 -daca Id gresit
        """
        ok=0
        try:
            idE=int(idE)
            v=self.__repoEvent.get_AllEvents()         
            self.__repoEvent.remove_Event(idE)
            self.__repoInscrieri.removeEvent(idE)   
            if v==self.__repoEvent.get_AllEvents():
                ok=1
        except ValueError:
            ok=2

        return ok
    
    def service_modificareEvent(self,idE,data,durata,descriere):
        """
        Modifica eveniment din lista de evenimente
        Returneaza 1 -daca s-a efectuat
        Returneaza 0 -daca nu exista evenimentul
        """
        ok=0
        try:  
            self.__validareEvent.validareDataType(idE,data,durata,descriere)
            self.__validareEvent.verif_data(data)
            self.__validareEvent.verif_durata(durata) 
            idE=int(idE)
            self.__repoEvent.modificare_Event(idE,data,durata,descriere)
        except ValidError as ve:
            #print(ve) 
            ok=1
        if ok==1 or self.service_cautareEvent(str(idE))==0:    
            return 0
        else:
            return 1
    
    def service_cautareEvent(self,idE):
        """
        Cauta eveniment din lista de evenimente dupa ID
        Returneaza evenimentul -daca exista
        Returneaza 0 -daca nu exista
        """
        ok=0
        try:
            idE=int(idE)
            k=self.__repoEvent.cautare_Event(idE)
        except ValueError:
            ok=1
        if ok==1:
            return 0
        return k
    
    def __generate_idE(self):
        """
        Genereaza id unic
        Returneaza id
        """
        n=str(random.randrange(1,100000))
        if self.service_cautareEvent(n)==0:
            return n
        while self.service_cautareEvent(n)!=0:
            n=str(random.randrange(1,100000))
        return n
    
    def __generate_dataE(self):
        """
        Genereaza data
        Returneaza data
        """
        return str(random.randrange(1,28))+'/'+str(random.randrange(1,12))+'/'+str(random.randrange(1900,2100))
    
    def __generate_oraE(self):
        """
        Genereaza ora
        Returneaza ora
        """
        return str(random.randrange(1,100))+':'+str(random.randrange(1,59))
    
    def __generate_descriereE(self):
        """
        Genereaza descriere
        Returneaza descriere
        """
        letters = string.ascii_letters
        return (''.join(random.choice(letters) for i in range(random.randrange(1,25))))
    
    def generare_random_Event(self,nr):
        """
        Genereaza numarul dorit de evenimente
        Returneaza 1 -numar invalid
        Returneaza 0 -adaugare efectuata
        """
        ok=0
        try:
            nr=int(nr)
            if nr<=0:
                return 1
            while nr:
                self.service_adaugareEvent(self.__generate_idE(), self.__generate_dataE(), self.__generate_oraE(), self.__generate_descriereE())
                nr-=1
        except ValueError:
            ok=1
            
        return ok


class ServicePers:
    """
    Clasa pentru Service PERSOANE
    """
    def __init__(self, validarePers, repoPers, repoInscrieri):
        self.__validarePers = validarePers
        self.__repoPers = repoPers
        self.__repoInscrieri = repoInscrieri
    
    def service_getALL_Pers(self):
        """
        Returneaza toate persoanele
        """
        return self.__repoPers.get_AllPers()
    
    def service_adaugarePers(self,idP,nume,adr):
        """
        Adauga persoana noua in lista de persoane
        Returneaza 1 -adaugare efectuata
        Returneaza 0 -daca nu exista
        """
        ok=1
        try:
            self.__validarePers.verif_allCRT_pers(self.__repoPers.get_AllPers(),idP,nume,adr)
            p=Persoane(idP,nume,adr)
            self.__validarePers.validare_pers(p)
                    
            self.__repoPers.add_Pers(p)
        except ValidError as ve:
            #print(ve)
            ok=0
        if ok==1:
            return 1
        return 0
    
    def service_stregerePers(self,idP):
        """
        Sterge eveniment din lista de persoane
        Returneaza 0 -daca s-a efectuat
        Returneaza 1 -daca nu s-a efectuat
        Returneaza 2 -daca Id gresit
        """
        ok=0
        try:
            idP=int(idP)
            v=self.__repoPers.get_AllPers()        
            self.__repoPers.remove_Pers(idP)
            self.__repoInscrieri.removePers(idP)
            if v==self.__repoPers.get_AllPers():
                ok=1
        except ValueError:
            ok=2
        return ok
    
    def service_modificarePers(self,idP,nume,adr):
        """
        Modifica persoanele din lista de persoane
        Returneaza 1 -realizat
        Returneaza 0 -daca nu exista
        """
        ok=0
        try:
            self.__validarePers.validareDataType(idP,nume,adr)
            self.__validarePers.verif_nume(nume)
            self.__validarePers.verif_adresa(adr)        
            idP=int(idP)
            self.__repoPers.modificare_Pers_rec(idP,nume,adr)
        except ValidError as ve:
            #print(ve) 
            ok=1
        if ok==1 or self.service_cautarePersID(str(idP))==0:    
            return 0
        else:
            return 1
    
    def service_cautarePersNUME(self,nume):
        """
        Cauta persoana din lista de persoane dupa Nume
        Returneaza persoanele -daca exista
        Returneaza 0 -daca nu exista
        """
        ok=0
        try:
            self.__validarePers.verif_nume(nume)
            nume=Nume(nume)            
            k=self.__repoPers.cautare_Pers_NUME(nume)
        except ValidError:
            ok=1
        if ok==1:
            return 0
        return k
    
    def service_cautarePersID(self,idP):
        """
        Cauta persoana din lista de persoane dupa ID
        Returneaza persoana -daca exista
        Returneaza 0 -daca nu exista
        """
        ok=0
        try:
            idP=int(idP)
            k=self.__repoPers.cautare_Pers_ID_rec(idP)
        except ValueError:
            ok=1
        if ok==1:
            return 0
        return k
    
    
    def __generate_idP(self):
        """
        Genereaza id unic
        Returneaza id
        """
        n=str(random.randrange(1,100000))
        if self.service_cautarePersID(n)==0:
            return n
        while self.service_cautarePersID(n)!=0:
            n=str(random.randrange(1,100000))
        return n

    def __generate_numeP(self):
        """
        Genereaza nume
        Returneaza nume
        """
        letters = string.ascii_letters
        return (''.join(random.choice(letters) for i in range(random.randrange(1,15))))+' '+(''.join(random.choice(letters) for i in range(random.randrange(1,15))))
    
    def __generate_adresaP(self):
        """
        Genereaza adresa
        Returneaza adresa
        """
        letters = string.ascii_letters
        return (''.join(random.choice(letters) for i in range(random.randrange(1,15))))+' '+str(random.randrange(1,100))
    
    
    def generare_random_Pers(self,nr):
        """
        Genereaza numarul dorit de persoane
        Returneaza 1 -numar invalid
        Returneaza 0 -adaugare efectuata
        """
        ok=0
        try:
            nr=int(nr)
            if nr<=0:
                return 1
            while nr:
                self.service_adaugarePers(self.__generate_idP(), self.__generate_numeP(), self.__generate_adresaP())
                nr-=1
        except ValueError:
            ok=1   
        return ok


class ServiceInscrieri:
    """
    Clasa pentru Service INSCRIERI
    """
    def __init__(self, repoInscriere, repoEvent, repoPers):
        self.__repoInscriere = repoInscriere
        self.__repoEvent = repoEvent
        self.__repoPers = repoPers
    
    def service_getAll_Inscrieri(self):
        """
        Returneaza toate inscrierile
        """
        return self.__repoInscriere.getAll_INSCRIERI()
    
    def service_InscrierePersEvent(self,persoanaID,evenimentID):
        """
        Inscrie persoana la eveniment
        Realizeaza inscrierea
        Returneaza 0 -pt inscriere realizata
        Returneaza 1 -id invalide
        Returneaza 2 -deja participi la acel event
        Returneaza 3 -inscriere esuata
        """
        ok=0#print("Inscriere complecta\n")
        try:
            persoanaID=int(persoanaID)
            evenimentID=int(evenimentID)
        except ValueError:
            return 1#print("ID-uri invalide!\n") 

        ok1=self.__repoPers.cautare_Pers_ID(persoanaID)
        ok2=self.__repoEvent.cautare_Event(evenimentID)
        
        if ok1!=0 and ok2!=0:
            if self.__repoInscriere.cautarePers(persoanaID)==0:
                self.__repoInscriere.newPers(persoanaID)
            if self.__repoInscriere.cautareEvent(persoanaID,evenimentID)==0:
                self.__repoInscriere.addEvent(persoanaID, evenimentID)
            else:
                ok=2#print("Deja participati la acest eveniment!\n")    
        else:
            ok=3#print("Inscriere esuata!\n")
        return ok
    
    
    def service_raport1(self,idP):
        """
        Realizeaza raportul 1
        Rezultatul va fi luat din lista cu particiapri a persoanei, iar apoi ordonata
        Returneaza lista cu evenimetele la care participa o persoana, ordonate dupa descriere si data
        Returneaza -1 daca datele sunt incorecte
        Returneaza 0 daca persoana nu exista
        """
        ok=0
        try:
            idP=int(idP)
            if self.__repoPers.cautare_Pers_ID(idP)==0:
                ok=-1
            if idP in self.__repoInscriere.getAll_INSCRIERI():
                ok=self.__repoInscriere.getAll_INSCRIERI()[idP]
            if ok!=0 and ok!=-1:
                if len(ok)>0:
                    ok=self.ordonare(ok, self.__repoEvent.get_AllEvents())
            else:
                return 0
        except ValueError:
            ok=-1
        return ok
    
    
    
    def service_raport2(self,nr):
        """
        Realizeaza raport 2
        Se va crea o loua lista cu rezultatul. Acest rezultat va fi format din retinerea id ului si a numarului de participari a acelei persoane
        Se va ordona in fct de participari
        Returneaza -1 pt date invalide
        Returneaza 0 pt numar prea mare sau prea mic de persoane
        Returneaza lista cu primele n pers, care participa la cele mai multe evenimente
        """
        rez=[]
        for i in self.__repoInscriere.getAll_INSCRIERI():
            rez.append(DTO_Rapoarte(i,len(self.__repoInscriere.getAll_INSCRIERI()[i])))
        try:
            nr=int(nr)
            if nr<0 or nr>len(rez):
                return 0#nr nu e bun
        except ValueError:
            return -1#nu e numar
        
        rez=self.ordonareRez(rez)
        
        return rez[0:nr]
        
    
    def service_raport3(self):
        """
        Realizeaza raport 3
        Se va face cu ajutorul unei liste, care va memora idul si popularitatea evenimentului, iar apoi le va sorta
        Returneaza lista cu cele mai populare 20% evenimente
        """
        rez=[]#un fel de vector de frecventa
        x=int(20/100*(len(self.__repoEvent.get_AllEvents())))
        for i in range (len(self.__repoEvent.get_AllEvents())):
            rez.append(DTO_Rapoarte(self.__repoEvent.get_AllEvents()[i].get_id(),0))
            
        for i in range (len(rez)):
            for j in self.__repoInscriere.getAll_INSCRIERI():
                if rez[i].get_key() in self.__repoInscriere.getAll_INSCRIERI()[j]:
                    rez[i].set_contor(rez[i].get_contor()+1)
        
        rez=self.ordonareRez(rez)
        
        return rez[0:x]
        
    
    
    
    def service_raport_lab(self,descriere):
        """
        Realizeaza raport lab
        Se va retine rezultatul intr-o lista, retinand cate cuvinte apar 
        Se adauga doar elementele care contin cel putin un cuvant cheie
        Se cauta persoanele care participa la un eveniment
        Returneaza rezultatul cu persoanele care participa la evenimentele cautate
        """
        descriere=descriere.upper()
        descriere=descriere.split()
        rez=[]
        for i in range (len(self.__repoEvent.get_AllEvents())):
            descEvent=self.__repoEvent.get_AllEvents()[i].get_descriere().split()
            ok=0
            for n in descriere:
                for m in descEvent:
                    if m==n:
                        ok+=1
            if ok==len(descriere):
                rez.append(DTO_Rapoarte(self.__repoEvent.get_AllEvents()[i],ok))
        
        
        rez_final=[]
        for i in range (len(rez)):
            for j in self.__repoInscriere.getAll_INSCRIERI():
                    for k in range (len(self.__repoInscriere.getAll_INSCRIERI()[j])):
                        if rez[i].get_key().get_id()==self.__repoInscriere.getAll_INSCRIERI()[j][k]:
                            rez_final.append(j)
        
        rez=[]
        for i in range (len(rez_final)):
            ok=0
            for j in range (len(rez)):
                if rez[j]==rez_final[i]:
                    ok=1
            if ok==0:
                rez.append(rez_final[i])
        
        return rez
    
    
    
    def ordonareRez(self,rez):
        """
        -MERGE SORT-
        Realizeaza ordonarea listei de rezultate descrescator
        Returneaza lista ordonata
        """
        for i in range (len(rez)):#ordonare rezultat
            for j in range (i,len(rez)):
                if rez[i].get_contor()<rez[j].get_contor():
                    rez[i],rez[j]=rez[j],rez[i]
        return rez
    
    
    
    def ordonare(self,ok,event):#ok = lista de participari
        """
        -BINGO SORT-
        Ordoneaza lista cu inscrierile in fct de descriere si data
        Returneaza lista ordonata
        """
        for i in range (len(ok)):
            for j in range(i,len(ok)):
                
                if self.__repoEvent.cautare_Event(ok[i]).get_descriere() > self.__repoEvent.cautare_Event(ok[j]).get_descriere():
                    ok[i],ok[j]=ok[j],ok[i]
                elif self.__repoEvent.cautare_Event(ok[i]).get_descriere() == self.__repoEvent.cautare_Event(ok[j]).get_descriere():
                    x1=self.__repoEvent.cautare_Event(ok[i]).get_data()
                    x2=self.__repoEvent.cautare_Event(ok[j]).get_data()
                    d1 = datetime.datetime(int(x1.get_an()),int(x1.get_luna()), int(x1.get_zi())) 
                    d2 = datetime.datetime(int(x2.get_an()),int(x2.get_luna()), int(x2.get_zi())) 
                    if d1 > d2:
                        ok[i],ok[j]=ok[j],ok[i]
        return ok
