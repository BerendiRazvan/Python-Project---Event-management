
#from errorsApp.errors import RepoError
from domainApp.domain import Persoane,Evenimente




class RepoEventFISl:
    """
    Clasa pentru Repository EVENIMENTE
    RepoEvent: [event_1, event_2, ..., event_n]
    """
    def __init__(self,fisier):
        self.__numefis=fisier
    
    def get_AllEvents(self):
        """
        Returneaza lista de evenimente
        """
        f=open(self.__numefis,"r")
        line = f.readline().strip()

        fis=open("new.txt","w")
        f=open(self.__numefis,"r")
        try:
            line = f.readline().strip()
            while line!="":
                fis.write(line+"\n")
                line = f.readline().strip()
        finally:
            f.close()
            fis.close()
        
    
    def add_Event(self,e):
        """
        Adauga eveniment
        """
        exista=0
        self.__get_AllEvents()
        fis=open(self.__numefis,"a")
        f=open("new.txt","r")
        try:
            line = f.readline().strip()
            while line!="":
                ok=line.split(";")
                if int(ok[0])==e.get_id():
                    exista=1
                line = f.readline().strip()
            
            if exista==0:
                newLine=str(e.get_id())+";"+str(e.get_data())+";"+str(e.get_timp().get_ore())+":"+str(e.get_timp().get_min())+";"+e.get_descriere()+";\n"
                fis.write(newLine)   
                
        finally:
            f.close()
            fis.close()
        
        
    
    def remove_Event(self,idE):
        """
        Sterge eveniment
        """
        
        fis=open("new.txt","w")
        f=open(self.__numefis,"r")
        try:
            line = f.readline().strip()
            while line!="":
                ok=line.split(";")
                if int(ok[0])!=idE:
                    fis.write(line+"\n")
                line = f.readline().strip()  
                
        finally:
            f.close()
            fis.close()
            
        fis=open(self.__numefis,"w")
        f=open("new.txt","r")
        
        try:
            line = f.readline().strip()
            while line!="":
                fis.write(line+"\n")
                line = f.readline().strip()      
        finally:
            f.close()
            fis.close()
            
    
    def modificare_Event(self,idE,data,timp,descriere):
        """
        Modifica eveniment
        """
        fis=open("new.txt","w")
        f=open(self.__numefis,"r")
        try:
            line = f.readline().strip()
            while line!="":
                ok=line.split(";")
                if int(ok[0])==idE:
                    newLine=str(idE)+";"+data+";"+timp+";"+descriere.upper()+";\n"
                    fis.write(newLine)
                else:
                    fis.write(line+"\n")
                line = f.readline().strip()  
                
        finally:
            f.close()
            fis.close()
            
        fis=open(self.__numefis,"w")
        f=open("new.txt","r")
        
        try:
            line = f.readline().strip()
            while line!="":
                fis.write(line+"\n")
                line = f.readline().strip()      
        finally:
            f.close()
            fis.close()
    
    def cautare_Event(self,idE):
        """
        Cautare eveniment dupa ID
        Returneaza eveniment -daca exista
        Returneaza 0 -daca nu exista
        """ 
        f=open(self.__numefis,"r")
        try:
            line = f.readline().strip()
            while line!="":
                ok=line.split(";")
                if int(ok[0])==idE:
                    print(line)
                line = f.readline().strip()  
                
        finally:
            f.close()


