#from errorsApp.errors import RepoError
from domainApp.domain import Persoane,Evenimente


class RepoEvent:
    """
    Clasa pentru Repository EVENIMENTE
    RepoEvent: [event_1, event_2, ..., event_n]
    """
    
    def __init__(self):
        """
        INIT:
        <event> -lista
        """
        self.__event=[]
      
    def __len__(self):
        """
        Returneaza lungimea listei de evenimente
        """
        return len(self.__event)
    
    def get_AllEvents(self):
        """
        Returneaza lista de evenimente
        """
        return self.__event[:]
    
    def add_Event(self,e):
        """
        Adauga eveniment
        """
        self.__event.append(e)
    
    def remove_Event(self,idE):
        """
        Sterge eveniment
        """
        i=0
        while i<len(self.__event):
            if self.__event[i].get_id()==idE:
                self.__event.remove(self.__event[i])
                i-=1
            i+=1
            
    
    def modificare_Event(self,idE,data,timp,descriere):
        """
        Modifica eveniment
        """
        for i in range (len(self.__event)):
            if self.__event[i].get_id()==idE:
                self.__event[i].set_data(data)
                self.__event[i].set_timp(timp)
                self.__event[i].set_descriere(descriere)
        
    
    def cautare_Event(self,idE):
        """
        Cautare eveniment dupa ID
        Returneaza eveniment -daca exista
        Returneaza 0 -daca nu exista
        """ 
        ok=0
        for i in range (len(self.__event)):
            if(self.__event[i].get_id()==idE):
                e=self.__event[i]
                ok=1
        if ok==1:
            return e
        else:
            return 0


class RepoPers:
    """
    Clasa pentru Repository PERSOANE
    RepoPers: [pers_1, pers_2, ..., pers_n]
    """
    def __init__(self):
        """
        INIT:
        <pers> -lista
        """
        self.__pers=[]

    
    def __len__(self):
        """
        Returneaza lungimea listei de persoane
        """
        return len(self.__pers)
    
    def get_AllPers(self):
        """
        Returneaza lista de persoane
        """
        return self.__pers[:]
        
    
    def add_Pers(self,p):
        """
        Adauga persoana
        """
        self.__pers.append(p)
        
    
    def remove_Pers(self,idP):
        """
        Sterge persoana
        """
        i=0
        while i<len(self.__pers):
            if self.__pers[i].get_persID()==idP:
                self.__pers.remove(self.__pers[i])
                i-=1
            i+=1
        
    
    def modificare_Pers(self,idP,nume,adr):
        """
        Modifica persoana
        """ 
        for i in range (len(self.__pers)):
            if self.__pers[i].get_persID()==idP:
                self.__pers[i].set_nume(nume)
                self.__pers[i].set_adresa(adr)
        
    def modificare_Pers_rec(self,idP,nume,adr):
        """
        Apeleaza functia recursiva de modificare
        """
        self.__modificare_Pers_recursiv(idP, nume, adr, len(self.__pers)-1)
    
    def __modificare_Pers_recursiv(self,idP,nume,adr,i):
        """
        Modifica persoana - Varianta recursiva
        """ 
        if i==-1:
            return
        
        if self.__pers[i].get_persID()==idP:
            self.__pers[i].set_nume(nume)
            self.__pers[i].set_adresa(adr)
            
        return self.__modificare_Pers_recursiv(idP,nume,adr,i-1)
        
    
    def cautare_Pers_NUME(self,nume):
        """
        Cautare persoane dupa nume
        Returneaza persoanele -daca exista
        Returneaza 0 -daca nu exista
        """ 
        ok=0
        p=[]
        for i in range (len(self.__pers)):
            if self.__pers[i].get_nume().get_nume()==nume.get_nume() and self.__pers[i].get_nume().get_prenume()==nume.get_prenume() or self.__pers[i].get_nume().get_nume()==nume.get_prenume() and self.__pers[i].get_nume().get_prenume()==nume.get_nume():
                p.append(self.__pers[i])
                ok=1
        if ok==1:
            return p
        else:
            return 0
        
    def cautare_Pers_ID(self,idP):
        """
        Cautare persoane dupa ID
        Returneaza persoana -daca exista
        Returneaza 0 -daca nu exista
        """ 
        ok=0
        for i in range (len(self.__pers)):
            if(self.__pers[i].get_persID()==idP):
                p=self.__pers[i]
                ok=1
        if ok==1:
            return p
        else:
            return 0
        
    def cautare_Pers_ID_rec(self,idP):
        """
        Apeleaza functia recursiva pentru cautare
        """ 
        return self.__cautare_Pers_ID_recursiv(idP,len(self.__pers)-1)
        
    def __cautare_Pers_ID_recursiv(self,idP,i):
        """
        Cautare persoane dupa ID - Varianta recursiva
        Returneaza persoana -daca exista
        Returneaza 0 -daca nu exista
        """ 
        if i==-1:
            return 0
        
        if(self.__pers[i].get_persID()==idP):
            return self.__pers[i]
        
        return self.__cautare_Pers_ID_recursiv(idP, i-1)

class RepoInscrieri:
    """
    Clasa pentru Repository INSCRIERI
    RepoInscrieri: {persID_1:[eventID_1, eventID_2, ...,eventID_m], persID_2:[eventID_1, eventID_2, ...,eventID_m], ..., persID_n:[eventID_1, eventID_2, ...,eventID_m]}
    """
    def __init__(self):
        """
        INIT:
        <inscrieri> -dictionar
        """
        self.__inscrieri={}
    
    def getAll_INSCRIERI(self):
        """
        Returneaza dictionarul de inscrieri
        """
        return self.__inscrieri       
    
    def newPers(self,persoanaID):
        """
        Creaza dictionar nou special pentru o persoana
        """
        self.__inscrieri.update({persoanaID:[]})

    
    def addEvent(self,persoanaID,evenimentID):
        """
        Adauga eveniment
        """
        self.__inscrieri[persoanaID].append(evenimentID)
 
    
    def removeEvent(self,idevent):
        """
        Elimina un eveniment din inscrieri dupa ce acesta a fost sters
        """
        for i in self.__inscrieri:
            if idevent in self.__inscrieri[i]:
                self.__inscrieri[i].remove(idevent)
        
        self.removePersFaraInscrieri()
    
    def removePersFaraInscrieri(self):
        """
        Elimina o persoana din inscrieri daca aceasta nu mai participala niciun eveniment
        """
        gol=[]
        for i in self.__inscrieri:
            if self.__inscrieri[i]==[]:
                gol.append(i)
        for i in range (len(gol)):
            if gol[i] in self.__inscrieri:
                self.__inscrieri.pop(gol[i])
                
    
    def removePers(self,x):
        """
        Elimina o persoana din inscrieri dupa ce aceasta a fost stearsa
        """
        if x in self.__inscrieri:
            self.__inscrieri.pop(x)
    
    def numberEvents(self,idul):
        """
        Returneaza numarul de evenimente
        """
        return len(self.__inscrieri[idul])
    
    def cautarePers(self,persoanaID):
        """
        Verifica daca o persoana are deja dictionar
        Return 1 - true
        Return 0 - false 
        """
        if persoanaID in self.__inscrieri:
            return 1
        else:
            return 0
    
    def cautareEvent(self,persoanaID,evenimentID):
        """
        Verifica daca o persoana participa deja la un eveniment
        Return 1 - true
        Return 0 - false 
        """
        if persoanaID in self.__inscrieri:
            if evenimentID in self.__inscrieri[persoanaID] :
                return 1
        return 0


