#from errorsApp.errors import RepoError
from domainApp.domain import Persoane,Evenimente


class RepoEventFIS:
    """
    Clasa pentru Repository EVENIMENTE
    RepoEvent: [event_1, event_2, ..., event_n]
    """
    
    def __init__(self,fisier):
        """
        INIT:
        <event> -lista
        """
        self.__fisier=fisier
        self.__event=self.__load_AllEventData()
        #self.__event=[]
      
    def __load_AllEventData(self):
        rez=[]
        with open(self.__fisier,"r") as myEvents:
            for line in myEvents:
                event=line.split(";")
                rez.append(Evenimente(event[0],event[1],event[2],event[3]))
        return rez[:]
    
    def __save_EventData(self,events):
        with open(self.__fisier,"w") as myEvents:
            for e in events:
                newLine=str(e.get_id())+";"+str(e.get_data())+";"+str(e.get_timp().get_ore())+":"+str(e.get_timp().get_min())+";"+e.get_descriere()+";\n"
                myEvents.write(newLine)
                
    def __len__(self):
        """
        Returneaza lungimea listei de evenimente
        """
        return len(self.__event)
    
    def get_AllEvents(self):
        """
        Returneaza lista de evenimente
        """
        self.__event=self.__load_AllEventData()
        
        return self.__event[:]
    
    def add_Event(self,e):
        """
        Adauga eveniment
        """
        self.__event=self.__load_AllEventData()
        
        
        self.__event.append(e)
        self.__save_EventData(self.__event)
    
    def remove_Event(self,idE):
        """
        Sterge eveniment
        """
        self.__event=self.__load_AllEventData()
        
        
        i=0
        while i<len(self.__event):
            if self.__event[i].get_id()==idE:
                self.__event.remove(self.__event[i])
                i-=1
            i+=1
        self.__save_EventData(self.__event)
            
    
    def modificare_Event(self,idE,data,timp,descriere):
        """
        Modifica eveniment
        """
        self.__event=self.__load_AllEventData()
        
        
        for i in range (len(self.__event)):
            if self.__event[i].get_id()==idE:
                self.__event[i].set_data(data)
                self.__event[i].set_timp(timp)
                self.__event[i].set_descriere(descriere)
        self.__save_EventData(self.__event)
    
    def cautare_Event(self,idE):
        """
        Cautare eveniment dupa ID
        Returneaza eveniment -daca exista
        Returneaza 0 -daca nu exista
        """ 
        self.__event=self.__load_AllEventData()
        
        
        ok=0
        for i in range (len(self.__event)):
            if(self.__event[i].get_id()==idE):
                e=self.__event[i]
                ok=1
        if ok==1:
            return e
        else:
            return 0

class RepoPersFIS:
    """
    Clasa pentru Repository PERSOANE
    RepoPers: [pers_1, pers_2, ..., pers_n]
    """
    def __init__(self,fisier):
        """
        INIT:
        <pers> -lista
        """
        self.__fisier=fisier
        self.__pers=self.__load_AllPersData()
        #self.__pers=[]
    
    
    def __load_AllPersData(self):
        rez=[]
        with open(self.__fisier,"r") as myPers:
            for line in myPers:
                pers=line.split(";")
                rez.append(Persoane(pers[0],pers[1],pers[2]))
        return rez[:]
      
    
    def __save_PersData(self,pers):
        with open(self.__fisier,"w") as myPers:
            for p in pers:
                newLine=str(p.get_persID())+";"+str(p.get_nume())+";"+p.get_adresa().get_strada()+" "+p.get_adresa().get_nrStrada()+";\n"
                myPers.write(newLine)
    
    def __len__(self):
        """
        Returneaza lungimea listei de persoane
        """
        return len(self.__pers)
    
    def get_AllPers(self):
        """
        Returneaza lista de persoane
        """
        return self.__pers[:]
        
    
    def add_Pers(self,p):
        """
        Adauga persoana
        """
        self.__pers.append(p)
        self.__save_PersData(self.__pers)
    
    def remove_Pers(self,idP):
        """
        Sterge persoana
        """
        i=0
        while i<len(self.__pers):
            if self.__pers[i].get_persID()==idP:
                self.__pers.remove(self.__pers[i])
                i-=1
            i+=1
        self.__save_PersData(self.__pers)
    
    def modificare_Pers(self,idP,nume,adr):
        """
        Modifica persoana
        """ 
        for i in range (len(self.__pers)):
            if self.__pers[i].get_persID()==idP:
                self.__pers[i].set_nume(nume)
                self.__pers[i].set_adresa(adr)
        self.__save_PersData(self.__pers)
    
    
    def modificare_Pers_rec(self,idP,nume,adr):
        self.__modificare_Pers_recursiv(idP, nume, adr, len(self.__pers)-1)
    
    def __modificare_Pers_recursiv(self,idP,nume,adr,i):
        """
        Modifica persoana - Varianta recursiva
        """ 
        if i==-1:
            self.__save_PersData(self.__pers)
            return
        
        if self.__pers[i].get_persID()==idP:
            self.__pers[i].set_nume(nume)
            self.__pers[i].set_adresa(adr)
        
        return self.__modificare_Pers_recursiv(idP,nume,adr,i-1)
        
        
    
    def cautare_Pers_NUME(self,nume):
        """
        Cautare persoane dupa nume
        Returneaza persoanele -daca exista
        Returneaza 0 -daca nu exista
        """ 
        ok=0
        p=[]
        for i in range (len(self.__pers)):
            if self.__pers[i].get_nume().get_nume()==nume.get_nume() and self.__pers[i].get_nume().get_prenume()==nume.get_prenume() or self.__pers[i].get_nume().get_nume()==nume.get_prenume() and self.__pers[i].get_nume().get_prenume()==nume.get_nume():
                p.append(self.__pers[i])
                ok=1
        if ok==1:
            return p
        else:
            return 0
        
    def cautare_Pers_ID(self,idP):
        """
        Cautare persoane dupa ID
        Returneaza persoana -daca exista
        Returneaza 0 -daca nu exista
        """ 
        ok=0
        for i in range (len(self.__pers)):
            if(self.__pers[i].get_persID()==idP):
                p=self.__pers[i]
                ok=1
        if ok==1:
            return p
        else:
            return 0
        
    def cautare_Pers_ID_rec(self,idP):
        """
        Apeleaza functia recursiva pentru cautare
        """ 
        return self.__cautare_Pers_ID_recursiv(idP,len(self.__pers)-1)
        
    def __cautare_Pers_ID_recursiv(self,idP,i):
        """
        Cautare persoane dupa ID - Varianta recursiva
        Returneaza persoana -daca exista
        Returneaza 0 -daca nu exista
        """ 
        if i==-1:
            return 0
        
        if(self.__pers[i].get_persID()==idP):
            return self.__pers[i]
        
        return self.__cautare_Pers_ID_recursiv(idP, i-1)



class RepoInscrieriFIS:
    """
    Clasa pentru Repository INSCRIERI
    RepoInscrieri: {persID_1:[eventID_1, eventID_2, ...,eventID_m], persID_2:[eventID_1, eventID_2, ...,eventID_m], ..., persID_n:[eventID_1, eventID_2, ...,eventID_m]}
    """
    def __init__(self,fisier):
        """
        INIT:
        <inscrieri> -dictionar
        """
        self.__fisier=fisier
        self.__inscrieri=self.__load_AllInscrieriData()
      
        
    def __load_AllInscrieriData(self):
        rez={}
        with open(self.__fisier,"r") as myIscrieri:
            for line in myIscrieri:
                inscr=line.split(";")
                persoanaID=int(inscr[0])
                evenimentID=int(inscr[1])
                if persoanaID not in rez:
                    rez.update({persoanaID:[]}) 
                rez[persoanaID].append(evenimentID)
        return rez
    
    
    def __save_InscrieriData(self,inscr):
        with open(self.__fisier,"w") as myInscr:
            for i in inscr:
                for k in range (len(inscr[i])):
                    newLine=str(i)+";"+str(inscr[i][k])+";\n"
                    myInscr.write(newLine)
    
    def getAll_INSCRIERI(self):
        """
        Returneaza dictionarul de inscrieri
        """
        return self.__inscrieri       
    
    def newPers(self,persoanaID):
        """
        Creaza dictionar nou special pentru o persoana
        """
        self.__inscrieri.update({persoanaID:[]})


    
    def addEvent(self,persoanaID,evenimentID):
        """
        Adauga eveniment
        """
        self.__inscrieri[persoanaID].append(evenimentID)
        
        self.__save_InscrieriData(self.__inscrieri)
 
    
    def removeEvent(self,idevent):
        """
        Elimina un eveniment din inscrieri dupa ce acesta a fost sters
        """
        for i in self.__inscrieri:
            if idevent in self.__inscrieri[i]:
                self.__inscrieri[i].remove(idevent)
        
        self.removePersFaraInscrieri()
        
        self.__save_InscrieriData(self.__inscrieri)
    
    def removePersFaraInscrieri(self):
        """
        Elimina o persoana din inscrieri daca aceasta nu mai participala niciun eveniment
        """
        gol=[]
        for i in self.__inscrieri:
            if self.__inscrieri[i]==[]:
                gol.append(i)
        for i in range (len(gol)):
            if gol[i] in self.__inscrieri:
                self.__inscrieri.pop(gol[i])
                
    
    def removePers(self,x):
        """
        Elimina o persoana din inscrieri dupa ce aceasta a fost stearsa
        """
        if x in self.__inscrieri:
            self.__inscrieri.pop(x)
        
        self.__save_InscrieriData(self.__inscrieri)
    
    def numberEvents(self,idul):
        """
        Returneaza numarul de evenimente
        """
        return len(self.__inscrieri[idul])
    
    def cautarePers(self,persoanaID):
        """
        Verifica daca o persoana are deja dictionar
        Return 1 - true
        Return 0 - false 
        """
        if persoanaID in self.__inscrieri:
            return 1
        else:
            return 0
    
    def cautareEvent(self,persoanaID,evenimentID):
        """
        Verifica daca o persoana participa deja la un eveniment
        Return 1 - true
        Return 0 - false 
        """
        if persoanaID in self.__inscrieri:
            if evenimentID in self.__inscrieri[persoanaID] :
                return 1
        return 0

