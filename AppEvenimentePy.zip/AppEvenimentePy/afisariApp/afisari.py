def infoMeniu(com):
    """
    Ofera informatiile din meniu pentru fiecare comanda
    com - sir de caractere
    Afiseaza mesaje 
    """
    if com==0:
        print('\n')
        print("MENIU PRINCIPAL")
        print("1. Evenimente")
        print("2. Persoane")
        print("3. Inscrieri")
        print("4. Rapoarte")
        print("\n* - Vizualizare date")
        print("\nx - Inchide aplicatie")

    if com=='1':
        print('\n')
        print("MENIU Evenimente")
        print("1. Adaugare")
        print("2. Stergere")
        print("3. Modificare")
        print("4. Cautare")
        print("+. Adaugare random de evenimente")
        print("\nx - Inapoi")
        
    if com=='2':
        print('\n')
        print("MENIU Persoane")
        print("1. Adaugare")
        print("2. Stergere")
        print("3. Modificare")
        print("4. Cautare")
        print("+. Adaugare random de persoane")
        print("\nx - Inapoi")
        
    if com=='3':
        print('\n')
        print("MENIU Inscrieri")
        print("\n")
        
    if com=='4':
        print('\n')
        print("MENIU Rapoarte")
        print("1. Lista de evenimente la care participa o persoana ordonat alfabetic dupa descriere, dupa data")
        print("2. Persoane participante la cele mai multe evenimente")
        print("3. Primele 20% evenimente cu cei mai multi participanti (descriere, numar participanti)")
        print("4. Raport lab.")
        print("\nx - Inapoi")



