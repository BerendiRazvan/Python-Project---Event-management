'''
Created on 28 Nov 2020
Organizare Evenimente - Lab. 7-9, Lab. 10

@author: Razvan
'''
from testsApp.tests import TestDomain,TestValidators,TestRepository,TestRepoFIS,TestService
from domainApp.domain import Persoane,Evenimente
from validatorsApp.validators import ValidatorEvent,ValidatorPers
from repoApp.repository import RepoEvent,RepoPers,RepoInscrieri
from repoApp.repositoryFIS import RepoEventFIS,RepoInscrieriFIS,RepoPersFIS
from serviceApp.service import ServiceEvent,ServicePers,ServiceInscrieri
from uiApp.ui import UI
import unittest


if __name__=='__main__':  
    unittest.main(exit=False)
    #try:
    #    unittest.main()
    #except:
    #    pass

    validareEvent = ValidatorEvent()
    validarePers = ValidatorPers()
    
    alegere=input("Alege metoda salvare: |F-Fisiere|ALTCEVA-Memorie|<-- ")
    
    
    if alegere.upper()=='F':
        #pt varianta cu fisiere
        repoEvent = RepoEventFIS('evenimente.txt')
        repoPers = RepoPersFIS('persoane.txt')
        repoInscrieri = RepoInscrieriFIS('inscrieri.txt')
    
    else:
        #pt varianta fara fisiere
        repoEvent = RepoEvent()
        repoPers = RepoPers()
        repoInscrieri = RepoInscrieri()
        
        repoEvent.add_Event(Evenimente(1,"2/1/2019","6:30","Untold"))
        repoEvent.add_Event(Evenimente(2,"25/12/2021","2:0","Vine Craciunul"))
        repoEvent.add_Event(Evenimente(3,"1/1/2021","7:30","Revelion"))
        repoEvent.add_Event(Evenimente(4,"7/7/2021","1:30","Spectacol Special"))
        repoEvent.add_Event(Evenimente(5,"25/12/2021","2:10","Festival mancare"))
        repoEvent.add_Event(Evenimente(888,"2/12/2029","1:30","Untold"))
        repoEvent.add_Event(Evenimente(121,"33/9/2033","2:00","New Untold"))
        repoEvent.add_Event(Evenimente(77,"2/8/2021","2:30","Magic Untold music festival"))
        repoEvent.add_Event(Evenimente(33,"2/3/2020","7:30","Untold festival"))
        
        repoPers.add_Pers(Persoane(1,"Berendi Razvan","Rucar 9"))
        repoPers.add_Pers(Persoane(2,"Pop Maria","Lalele 12"))
        repoPers.add_Pers(Persoane(3,"Cristea alex","Plopilor 10"))
        repoPers.add_Pers(Persoane(4,"Muntean Cristian","Frunzisului 3"))
        
        repoInscrieri.newPers(1)
        repoInscrieri.addEvent(1, 2)
        repoInscrieri.addEvent(1, 1)
        repoInscrieri.addEvent(1, 5)
        repoInscrieri.addEvent(1, 121)
        repoInscrieri.newPers(3)
        repoInscrieri.addEvent(3, 2)
        repoInscrieri.addEvent(3, 1)
        repoInscrieri.addEvent(3, 121)
        repoInscrieri.newPers(2)
        repoInscrieri.addEvent(2, 1)
        repoInscrieri.newPers(4)
        repoInscrieri.addEvent(4, 1)
        repoInscrieri.addEvent(4, 2)
        repoInscrieri.addEvent(4, 5)
        repoInscrieri.addEvent(4, 3)
        

    
    serviceEvent = ServiceEvent(validareEvent, repoEvent, repoInscrieri)
    servicePers = ServicePers(validarePers, repoPers, repoInscrieri)
    serviceInscrieri = ServiceInscrieri(repoInscrieri,repoEvent,repoPers)
    
    
    cons=UI(serviceEvent,servicePers,serviceInscrieri)
    cons.run()
    
        