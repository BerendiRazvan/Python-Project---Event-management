from afisariApp.afisari import infoMeniu


class UI:
    
    def __init__(self, serviceEvent, servicePers, serviceInscrieri):
        self.__serviceEvent = serviceEvent
        self.__servicePers = servicePers
        self.__serviceInscrieri = serviceInscrieri

    
    def run(self):
        com=0
        print("Organizare Evenimente - Lab. 7-9, Lab. 10\n")

        while com!='X':
            infoMeniu(com)
            com=input("\nComanda dorita este:")
            com=com.upper()
            if com=="1":
                self.__comanda1(com)
            elif com=="2":
                self.__comanda2(com)
            elif com=="3":
                self.__comanda3(com)
            elif com=="4":
                self.__comanda4(com)
            
            elif com=="*":#in plus pt a ma putea verifica - se poate sterge
                print("\nEvenimente:")
                for i in self.__serviceEvent.service_getALL_Events():
                    print(i)
                print("\nPersoane:")
                for i in self.__servicePers.service_getALL_Pers():
                    print(i)
                print("\nInscrieri:")
                print(self.__serviceInscrieri.service_getAll_Inscrieri())
                

            elif com!="X":
                print("Comanda inexistenta!")
            
            if com!="X":
                com=0
        
        print("\nAplicatia a fost inchisa. Va multumim! :)")
    
    
    def __comanda1(self,com):
        """
        UI COMANDA 1
        Realizeaza functionalitatiile pentru gestionare evenimente
        Returneaza lista de evenimente dupa modificari
        """
        infoMeniu(com)
        
        while com!='X':
            com=input("\nComanda dorita este:")
            com=com.upper()
            
            if com=="1": 
                idE=input("ID eveniment:")
                data=input("Data eveniment:")
                durata=input("Durata eveniment:")
                descriere=input("Descriere eveniment:")
                k=self.__serviceEvent.service_adaugareEvent(idE,data,durata,descriere)
                if k!=0:
                    print("Eveniment adaugat")
                else:
                    print("Date invalide! Evenimentul nu a fost adaugat")
                    
            elif com=="2":
                idE=input("ID-ul evenimentului pe care doriti sa il stergeti:")
                k=self.__serviceEvent.service_stregereEvent(idE)
                if k==0:
                    print("Eveniment sters")
                elif k==1:
                    print("Nu exista evenimentul cu ID-ul",idE)
                elif k==2:
                    print("ID gresit!\n")
                
            elif com=="3":
                idE=input("ID-ul evenimentului pe care doriti sa o modificati:")
                data=input("Data eveniment:")
                durata=input("Durata eveniment:")
                descriere=input("Descriere eveniment:")

                k=self.__serviceEvent.service_modificareEvent(idE,data,durata,descriere)
                
                if k==1:
                    print("Eveniment modificat")
                else:
                    print("Evenimentul nu a fost modificat!")
                    
            elif com=="4":
                idE=input("ID-ul evenimentului pe care doriti sa il cautati:")

                k=self.__serviceEvent.service_cautareEvent(idE)
                if k==0:
                    print("Id inexistent!")
                else:
                    print(k)
            
            elif com=="+":
                nr=input("Numar evenimente pe care doriti sa il generati:")

                k=self.__serviceEvent.generare_random_Event(nr)
                if k==1:
                    print("Numar invalid!")
                else:
                    print("Evenimete adaugate")
  
            elif com!="X":
                print("Comanda inexistenta!")
  
            elif com!="X":
                print("Comanda inexistenta!")
            
            if com!="X":
                com=0
    
    
    def __comanda2(self,com):
        """
        UI COMANDA 2
        Realizeaza functionalitatiile pentru gestionare persoane
        Returneaza lista de persoane dupa modificari
        """
        infoMeniu(com)
        
        while com!='X':
            com=input("\nComanda dorita este:")
            com=com.upper()
            
            if com=="1":
                idP=input("ID persoana:")
                nume=input("Numele si prenumele persoanei:")
                adr=input("Adresa persoanei:")
                
                k=self.__servicePers.service_adaugarePers(idP,nume,adr)
                
                if k!=0:
                    print("Persoana adaugata")
                else:
                    print("Date invalide! Persoana nu a fost adaugata")
                
            elif com=="2":
                idP=input("ID-ul persoanei pe care doriti sa o stergeti:")

                k=self.__servicePers.service_stregerePers(idP)
                if k!=1 and k!=2:
                    print("Persoana stersa")
                elif k==1:
                    print("Nu exista persoana cu ID-ul",idP)
                elif k==2:
                    print("ID gresit!\n")
                
            elif com=="3":
                idP=input("ID-ul persoanei pe care doriti sa o modificati:")
                nume=input("Numele si prenumele persoanei:")
                adr=input("Adresa persoanei:")

                k=self.__servicePers.service_modificarePers(idP,nume,adr)
                    
                if k!=0:
                    print("Persoana modificata")
                else:
                    print("Persoana nu a fost modificata!")
                
            elif com=="4":
                nume=input("Numele persoanei pe care doriti sa o cautati:")

                k=self.__servicePers.service_cautarePersNUME(nume)
                if k==0:
                    print("Nu am gasit persoana!")
                else:
                    for i in range (len(k)):
                        print(k[i])
            
            elif com=="+":
                nr=input("Numar persoane pe care doriti sa il generati:")
                
                k=self.__servicePers.generare_random_Pers(nr)
                if k==1:
                    print("Numar invalid!")
                else:
                    print("Persoane adaugate")
                
            elif com!="X":
                print("Comanda inexistenta!")
            
            if com!="X":
                com=0

    
    
    def __comanda3(self,com):
        """      
        UI COMANDA 3
        Se va realiza inscrierea persoanelor la evenimente
        """
        infoMeniu(com)
        persoanaID=input("Introduceti ID-ul persoanei:")
        evenimentID=input("Introduceti ID-ul evenimetului la care doriti sa va inscrieti:")

        k=self.__serviceInscrieri.service_InscrierePersEvent(persoanaID,evenimentID)
        if k==0:
            print("Inscriere complecta\n")
        elif k==1:
            print("ID-uri invalide!\n")
        elif k==2:
            print("Deja participati la acest eveniment!\n")   
        elif k==3:
            print("Inscriere esuata, nu exista aceste ID-uri! \n")
    
    def __comanda4(self,com):
        """
        
        UI COMANDA 4
        ...
        """
        infoMeniu(com)
        while com!='X':
            com=input("\nComanda dorita este:")
            com=com.upper()
            if com=="1":
                idP=input("ID-ul persoanei:")
                k=self.__serviceInscrieri.service_raport1(idP)
                if k==-1:
                    print("ID-ul este invalid!")
                elif k==0:
                    print("Aceasta persoana nu exista!")
                else:
                    print("Evenimentele la care participa sunt:\n")
                    for i in range (len(k)):#afisam mai frumos lista
                        print(self.__serviceEvent.service_cautareEvent(str(k[i])))
            elif com=="2":
                nr=input("Introduceti nr. de persoane:")
                k=self.__serviceInscrieri.service_raport2(nr)
                if k==0:
                    print ("Nu exista atat de multe persoane!")
                elif k==-1:
                    print("Date introduse gresit!")
                else:
                    print ("Persoanele cu cele mai multe participari sunt:\n")
                    for i in range (len(k)):
                        print(self.__servicePers.service_cautarePersID(k[i].get_key()).get_nume()," participa la ", k[i].get_contor()," evenimente.")
            
            elif com=="3":
                k=self.__serviceInscrieri.service_raport3()
                if k==[]:
                    print ("Prea putine evenimente, pt a avea un procent de 20%")
                else:
                    for i in range (len(k)):
                        print("Evenimentul: ",self.__serviceEvent.service_cautareEvent(k[i].get_key()).get_descriere()," are ",k[i].get_contor()," participanti.")
            
            
            elif com=="4":
                descriere=input("Introduceti descrierea:")
                k=self.__serviceInscrieri.service_raport_lab(descriere)
                if len(k)==0:
                    print ("Nu exista persoane care sa participe la evenimente cu aceasta descrire!")
                for i in range (len(k)):
                    print(self.__servicePers.service_cautarePersID(k[i]).get_nume())
            
            elif com!="X":
                print("Comanda inexistenta!")
            
            if com!="X":
                com=0
