class ValidError(Exception):
    pass

class RepoError(Exception):
    pass
