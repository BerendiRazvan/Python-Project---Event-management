from errorsApp.errors import ValidError

class ValidatorEvent:
    
    def verif_IDevent(self,events,idE):
        """
        Valideaza ID
        Arunca erori daca ID este invalid
        """
        for i in range (len(events)):
            if events[i].get_id()==idE:
                raise ValidError("ID existent!\n")
    
    def verif_data(self,data):
        """
        Valideaza data
        Arunca erori daca data este invalida
        """
        data=data.upper()
        data=data.split('/')
        try:
            a=int(data[2])
            l=int(data[1])
            z=int(data[0])
        except ValueError:
            raise ValidError("Data invalida!\n")
        except IndexError:
            raise ValidError("Data invalida!\n")
        luna = [ 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ]
        if a<0:
            raise ValidError("Data invalida!\n")
        elif l<0 or l>12:
            raise ValidError("Data invalida!\n")
        elif z<0 or z>luna[l-1]:
            raise ValidError("Data invalida!\n")
    
    def verif_durata(self,t):
        """
        Valideaza timpul
        Arunca erori daca timpul este invalid
        """
        t=t.split(':')
        try:
            h=int(t[0])
            m=int(t[1])
        except ValueError:
            raise ValidError("Timp invalid!\n")
        except IndexError:
            raise ValidError("Timp invalid!\n")
        
        if h<0:
            raise ValidError("Timp invalid!\n")
        elif m<0 or m>59:
            raise ValidError("Timp invalid!\n")
    
    def validareDataType(self,idE,data,durata,descriere):
        """
        Valideaza tipurile datelor
        Arunca erori daca sunt invalide
        """
        erori=""
        
        if idE.isdigit()==False:
            erori+="Id invalid!\n"
            
        if data=="":
            erori+="Data invalida!\n"
        
        if durata=="":
            erori+="Timp invalid!\n"
        
        if descriere=="":
            erori+="Descriere invalida!\n"
            
        if len(erori)>0:
            raise ValidError(erori)
    
    def verif_allCRT_event(self,events,idE,data,durata,descriere):
        valid=ValidatorEvent()
        try:
            valid.validareDataType(idE,data,durata,descriere)
            valid.verif_data(data)
            valid.verif_durata(durata)
            idE=int(idE)
            valid.verif_IDevent(events,idE)
        except ValidError as ve:
            raise ve
    
    
    
    def validare_event(self,e):
        """
        Valideaza evenimentul
        Arunca erori daca evenimentul este invalid
        """
        erori=""
        
        if e.get_id()<0:
            erori+="Id invalid!\n"
        if e.get_data()=="":
            erori+="Data invalida!\n"
        if e.get_timp()=="":
            erori+="Timp invalid!\n"
        if e.get_descriere()=="":
            erori+="Descriere invalida!\n"
        if len(erori)>0:
            raise ValidError(erori)


class ValidatorPers:
    
    def verif_IDpers(self,pers,idP):
        """
        Valideaza ID
        Arunca erori daca ID este invalid
        """
        for i in range (len(pers)):
            if pers[i].get_persID()==idP:
                raise ValidError("ID existent!\n")
    
    def verif_nume(self,nume):
        """
        Valideaza numele
        Arunca erori daca numele este invalid
        """
        nume=nume.upper()
        nume=nume.split(" ")
        if len(nume)!=2:
            raise ValidError("Nume invalid!\n")
        elif nume[0].isdigit()==True or nume[1].isdigit()==True:
            raise ValidError("Nume invalid!\n")
    
    def verif_adresa(self,adresa):
        """
        Valideaza adresa
        Arunca erori daca adresa este invalida
        """
        adresa=adresa.upper()
        adresa=adresa.split(" ")
        if len(adresa)!=2:
            raise ValidError("Adresa invalida!\n")
        elif adresa[0].isalpha()==False or adresa[1].isdigit()==False:
            raise ValidError("Adresa invalida!\n")
    
    def validareDataType(self,idP,nume,adr):
        """
        Valideaza tipurile de date
        Arunca erori daca sunt invalide
        """
        erori=""
        
        if idP.isdigit()==False:
            erori+="Id invalid!\n"
        if nume=="":
            erori+="Nume invalid!\n"
        if adr=="":
            erori+="Adresa invalida!\n"
        if len(erori)>0:
            raise ValidError(erori)
    
    def verif_allCRT_pers(self,pers,idP,nume,adr):
        """
        Valideaza datele apeland toti validatorii
        Arunca erori daca datele sunt invalide
        """
        valid=ValidatorPers()
        try:
            valid.validareDataType(idP,nume,adr)
            idP=int(idP)
            valid.verif_IDpers(pers,idP)
            valid.verif_nume(nume)
            valid.verif_adresa(adr)
        except ValidError as ve:
            raise ve

    
    def validare_pers(self,p):
        """
        Valideaza persoana
        Arunca erori daca persoana este invalida
        """
        erori=""
        if p.get_persID()<0:
            erori+="Id invalid!\n"
        if p.get_nume()=="":
            erori+="Nume invalid!\n"
        if p.get_adresa()=="":
            erori+="Adresa invalida!\n"
        if len(erori)>0:
            raise ValidError(erori)


