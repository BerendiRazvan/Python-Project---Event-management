from domainApp.domain import Persoane,Evenimente,Nume,Data,Timp,Adresa,DTO_Rapoarte
from validatorsApp.validators import ValidatorEvent,ValidatorPers
from errorsApp.errors import ValidError
from repoApp.repository import RepoEvent,RepoPers,RepoInscrieri
from repoApp.repositoryFIS import RepoEventFIS,RepoInscrieriFIS,RepoPersFIS
from serviceApp.service import ServiceEvent,ServicePers,ServiceInscrieri
import unittest
            

class TestDomain(unittest.TestCase):
    #white box test
    
    def setUp(self):
        unittest.TestCase.setUp(self)
    
    def tearDown(self):
        unittest.TestCase.tearDown(self)
    
    def test_domain_event(self):
        ID=404
        data="25/12/2020"
        timp="2:30"
        descriere="Vine Craciunul"

        e=Evenimente(ID,data,timp,descriere)

        self.assertEqual(e.get_id(),404)
        self.assertEqual(e.get_data().get_an(),"2020")
        self.assertEqual(e.get_data().get_luna(),"12")
        self.assertEqual(e.get_data().get_zi(),"25")
        self.assertEqual(e.get_timp().get_min(),"30")
        self.assertEqual(e.get_timp().get_ore(),"2")
        self.assertEqual(e.get_descriere(),"VINE CRACIUNUL")
        
        e.set_id(1)
        e.set_data("2/1/2019")
        e.set_timp("6:30")
        e.set_descriere("UNTOLD")
        
        self.assertEqual(str(e),"1. Data: 2/1/2019; Durata: 6 ore si 30 minute; Descrierea: UNTOLD")
         
    
    def test_domain_pers(self):
        persID=101
        nume="Mos Craciun"
        adresa="Frunzisului 21"
        
        p=Persoane(persID,nume,adresa)
        
        self.assertEqual(p.get_persID(),101)
        self.assertEqual(p.get_nume().get_nume(),"MOS")
        self.assertEqual(p.get_nume().get_prenume(),"CRACIUN")
        self.assertEqual(p.get_adresa().get_strada(),"FRUNZISULUI")
        self.assertEqual(p.get_adresa().get_nrStrada(),"21")

        p.set_id(1)
        p.set_nume("BERENDI RAZVAN")
        p.set_adresa("RUCAR 9")

        self.assertEqual(str(p),"1. Nume si prenume: BERENDI RAZVAN; Adresa: Strada RUCAR nr.9")  
    
    def test_domain_data(self):
        data="2/12/2020"
        d=Data(data)
        
        self.assertEqual(d.get_zi(),"2")
        self.assertEqual(d.get_luna(),"12")
        self.assertEqual(d.get_an(),"2020")
        
        d.set_an("2021")
        d.set_luna("10")
        d.set_zi("3")

        self.assertEqual(str(d),"3/10/2021")
    
    def test_domain_timp(self):
        timp="2:30"
        t=Timp(timp)
        
        self.assertEqual(t.get_ore(),"2")
        self.assertEqual(t.get_min(),"30")
        
        t.set_min("15")
        t.set_ore("1")

        self.assertEqual(str(t),"1 ore si 15 minute")
    
    def test_domain_nume(self):
        nume="Razvan Alex"
        n=Nume(nume)
        
        self.assertEqual(n.get_nume(), "RAZVAN")
        self.assertEqual(n.get_prenume(), "ALEX")
        
        n.set_nume("Raul")
        n.set_prenume("Paul")
        
        self.assertEqual(str(n),"RAUL PAUL")
    
    def test_domain_adr(self):
        adr="str 1"
        a=Adresa(adr)
        
        self.assertEqual(a.get_strada(), "STR")
        self.assertEqual(a.get_nrStrada(), "1")
        
        a.set_strada("strada")
        a.set_nrStrada("2")
        
        self.assertEqual(str(a),"Strada STRADA nr.2")
    
    def test_domain_dto(self):
        dto=DTO_Rapoarte(1,3)
        
        self.assertEqual(dto.get_key(), 1)
        self.assertEqual(dto.get_contor(), 3)
        
        dto.set_contor(5)
        dto.set_key(5)
        
        self.assertEqual(dto.get_key(), 5)
        self.assertEqual(dto.get_contor(), 5)
        
    if __name__ == '__main__':
        unittest.main()


class TestValidators(unittest.TestCase):
    #white box test
    def setUp(self):
        self.__validare_e=ValidatorEvent()
        self.__validare_p=ValidatorPers()
        
        
    def tearDown(self):
        unittest.TestCase.tearDown(self)
    
    
    def test_validator_event(self):
        idul="-1"
        data=""
        timp=""
        descriere=""
        
        try:
            self.__validare_e.verif_allCRT_event([],idul, data, timp, descriere)
            e=Evenimente(idul,data,timp,descriere)
            self.__validare_e.validare_event(e)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Id invalid!\nData invalida!\nTimp invalid!\nDescriere invalida!\n")
            
        idul="4"
        data=""
        timp=""
        descriere=""
        
        try:
            self.__validare_e.verif_allCRT_event([],idul, data, timp, descriere)
            e=Evenimente(idul,data,timp,descriere)
            self.__validare_e.validare_event(e)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Data invalida!\nTimp invalid!\nDescriere invalida!\n")
            
        idul="5"
        data="3/10/2020"
        timp=""
        descriere=""
        
        try:
            self.__validare_e.verif_allCRT_event([],idul, data, timp, descriere)
            e=Evenimente(idul,data,timp,descriere)
            self.__validare_e.validare_event(e)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Timp invalid!\nDescriere invalida!\n")
        
        idul="45"
        data="2/2/2020"
        timp="2:30"
        descriere=""
        
        try:
            self.__validare_e.verif_allCRT_event([],idul, data, timp, descriere)
            e=Evenimente(idul,data,timp,descriere)
            self.__validare_e.validare_event(e)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Descriere invalida!\n")
        
        idul="45"
        data="2/2/2020"
        timp="2:30"
        descriere="Baiat bun"
        
        try:
            self.__validare_e.verif_allCRT_event([],idul, data, timp, descriere)
            e=Evenimente(idul,data,timp,descriere)
            self.__validare_e.validare_event(e)
            self.assertTrue( True )
        except ValidError as v:
            self.assertTrue( False )
    
    def test_validator_pers(self):
        idp="-2"
        nume=""
        adresa=""
        
        try:
            self.__validare_p.verif_allCRT_pers([],idp, nume, adresa)
            p=Persoane(idp,nume,adresa)
            self.__validare_p.validare_pers(p)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Id invalid!\nNume invalid!\nAdresa invalida!\n")
        
        idp="2"
        nume=""
        adresa=""
        
        try:
            self.__validare_p.verif_allCRT_pers([],idp, nume, adresa)
            p=Persoane(idp,nume,adresa)
            self.__validare_p.validare_pers(p)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Nume invalid!\nAdresa invalida!\n")
            
        idp="4"
        nume="Raz raz"
        adresa=""
        
        try:
            self.__validare_p.verif_allCRT_pers([],idp, nume, adresa)
            p=Persoane(idp,nume,adresa)
            self.__validare_p.validare_pers(p)
            self.assertTrue( False )
        except ValidError as v:
            self.assertEqual(str(v),"Adresa invalida!\n")  
            
        idp="6"
        nume="rasd dadsd"
        adresa="ras 4"
        
        try:
            self.__validare_p.verif_allCRT_pers([],idp, nume, adresa)
            p=Persoane(idp,nume,adresa)
            self.__validare_p.validare_pers(p)
            self.assertTrue(True)
        except ValidError as v:
            self.assertTrue(False) 
            
    if __name__ == '__main__':
        unittest.main()
    
       
class TestRepository(unittest.TestCase):
    #white box test
    def setUp(self):
        self.__repoEvent=RepoEvent()
        self.__repoPers=RepoPers()
        self.__repoInscrieri=RepoInscrieri()
        
        self.__repoEvent.add_Event(Evenimente(1,"2/1/2019","6:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(2,"25/12/2021","2:0","Vine Craciunul"))
        self.__repoEvent.add_Event(Evenimente(3,"1/1/2021","7:30","Revelion"))
        self.__repoEvent.add_Event(Evenimente(4,"7/7/2021","1:30","Spectacol Special"))
        self.__repoEvent.add_Event(Evenimente(5,"25/12/2021","2:10","Festival mancare"))
        self.__repoEvent.add_Event(Evenimente(888,"2/12/2029","1:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(121,"33/9/2033","2:00","New Untold"))
        self.__repoEvent.add_Event(Evenimente(77,"2/8/2021","2:30","Magic Untold music festival"))
        self.__repoEvent.add_Event(Evenimente(33,"2/3/2020","7:30","Untold festival"))
        
        self.__repoPers.add_Pers(Persoane(1,"Berendi Razvan","Rucar 9"))
        self.__repoPers.add_Pers(Persoane(2,"Pop Maria","Lalele 12"))
        self.__repoPers.add_Pers(Persoane(3,"Cristea alex","Plopilor 10"))
        self.__repoPers.add_Pers(Persoane(4,"Muntean Cristian","Frunzisului 3"))
        
        self.__repoInscrieri.newPers(1)
        self.__repoInscrieri.addEvent(1, 2)
        self.__repoInscrieri.addEvent(1, 1)
        self.__repoInscrieri.addEvent(1, 5)
        self.__repoInscrieri.addEvent(1, 121)
        self.__repoInscrieri.newPers(3)
        self.__repoInscrieri.addEvent(3, 2)
        self.__repoInscrieri.addEvent(3, 1)
        self.__repoInscrieri.addEvent(3, 121)
        self.__repoInscrieri.newPers(2)
        self.__repoInscrieri.addEvent(2, 1)
        self.__repoInscrieri.newPers(4)
        self.__repoInscrieri.addEvent(4, 1)
        self.__repoInscrieri.addEvent(4, 2)
        self.__repoInscrieri.addEvent(4, 5)
        self.__repoInscrieri.addEvent(4, 3)
        
        
    def tearDown(self):
        unittest.TestCase.tearDown(self)
    
    def test_get_AllEvents(self):
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),9)
        self.assertEqual( self.__repoEvent.get_AllEvents()[0].get_id(), 1)
        self.assertEqual( self.__repoEvent.get_AllEvents()[1].get_id(), 2)
        self.assertEqual( self.__repoEvent.get_AllEvents()[2].get_id(), 3)
        self.assertEqual( self.__repoEvent.get_AllEvents()[3].get_id(), 4)
        self.assertEqual( self.__repoEvent.get_AllEvents()[4].get_id(), 5)
        self.assertEqual( self.__repoEvent.get_AllEvents()[5].get_id(), 888)
        self.assertEqual( self.__repoEvent.get_AllEvents()[6].get_id(), 121)
        self.assertEqual( self.__repoEvent.get_AllEvents()[7].get_id(), 77)
        self.assertEqual( self.__repoEvent.get_AllEvents()[8].get_id(), 33)

    
    def test_add_Event(self):
        self.__repoEvent.add_Event(Evenimente(13,"2/3/2029","1:30","Super"))
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),10)
        self.assertEqual( self.__repoEvent.get_AllEvents()[9].get_id(), 13)
    
    def test_remove_Event(self):
        self.__repoEvent.remove_Event(2)
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),8)
        self.assertEqual( self.__repoEvent.get_AllEvents()[1].get_id(), 3)
        
            
    def test_modificare_Event(self):
        self.__repoEvent.modificare_Event(2,"2/2/2010","1:15","AAAA")
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),9)
        self.assertEqual(str(self.__repoEvent.get_AllEvents()[1]), "2. Data: 2/2/2010; Durata: 1 ore si 15 minute; Descrierea: AAAA")
        
        
    def test_cautare_Event(self):
        ok=self.__repoEvent.cautare_Event(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoEvent.get_AllEvents()[1])
        ok=self.__repoEvent.cautare_Event(34)
        self.assertEqual(ok,0)
        
    def test_get_AllPers(self):
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual( self.__repoPers.get_AllPers()[0].get_persID(), 1)
        self.assertEqual( self.__repoPers.get_AllPers()[1].get_persID(), 2)
        self.assertEqual( self.__repoPers.get_AllPers()[2].get_persID(), 3)
        self.assertEqual( self.__repoPers.get_AllPers()[3].get_persID(), 4)
        
    def test_add_Pers(self):
        self.__repoPers.add_Pers(Persoane(10,"AAA BBB","ADR 30"))
        self.assertEqual(len(self.__repoPers.get_AllPers()),5)
        self.assertEqual( self.__repoPers.get_AllPers()[4].get_persID(), 10)
        
    def test_remove_Pers(self):
        self.__repoPers.remove_Pers(2)
        self.assertEqual(len(self.__repoPers.get_AllPers()),3)
        self.assertEqual( self.__repoPers.get_AllPers()[1].get_persID(), 3)
        
    def test_modificare_Pers(self):
        self.__repoPers.modificare_Pers(2,"AAA BBB","AA 2")
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual(str(self.__repoPers.get_AllPers()[1]), "2. Nume si prenume: AAA BBB; Adresa: Strada AA nr.2")
    
    def test_modificare_Pers_rec(self):
        self.__repoPers.modificare_Pers_rec(2,"AAA BBB","AA 2")
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual(str(self.__repoPers.get_AllPers()[1]), "2. Nume si prenume: AAA BBB; Adresa: Strada AA nr.2")
    
    def test_cautare_Pers_ID(self):
        ok=self.__repoPers.cautare_Pers_ID(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoPers.get_AllPers()[1])
        ok=self.__repoPers.cautare_Pers_ID(34)
        self.assertEqual(ok,0)
        
    def test_cautare_Pers_ID_rec(self):
        ok=self.__repoPers.cautare_Pers_ID_rec(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoPers.get_AllPers()[1])
        ok=self.__repoPers.cautare_Pers_ID_rec(34)
        self.assertEqual(ok,0)
        
    def test_cautare_Pers_NUME(self):
        ok=self.__repoPers.cautare_Pers_NUME(Nume("BERENDI RAZVAN"))
        self.assertNotEqual(ok,0)
        self.assertEqual(ok[0],self.__repoPers.get_AllPers()[0])
        ok=self.__repoPers.cautare_Pers_NUME(Nume("Ananas mare"))
        self.assertEqual(ok,0)

    def test_getAll_INSCRIERI(self):  
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
    
    def test_newPers(self):
        self.__repoInscrieri.newPers(10)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3], 10: []})

    def test_addEvent(self):
        self.__repoInscrieri.addEvent(2,3)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1,3], 4: [1, 2, 5, 3]})
 
    def test_removeEvent(self):
        self.__repoInscrieri.removeEvent(1)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5, 121], 3: [2, 121], 4: [ 2, 5, 3]})
        self.__repoInscrieri.removeEvent(7)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5, 121], 3: [2, 121], 4: [ 2, 5, 3]})
        self.__repoInscrieri.removeEvent(121)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5], 3: [2], 4: [ 2, 5, 3]})
 
    
    def test_removePersFaraInscrieri(self):
        self.__repoInscrieri.newPers(10)
        self.__repoInscrieri.newPers(12)
        self.__repoInscrieri.newPers(11)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3], 10: [], 12: [], 11: []})
        self.__repoInscrieri.removePersFaraInscrieri()
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
           
    def test_removePers(self):
        self.__repoInscrieri.removePers(1)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(10)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(2)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(3)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{4: [1, 2, 5, 3]})     
        self.__repoInscrieri.removePers(4)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{})    
          
    
    def test_cautarePers(self):
        self.assertEqual(self.__repoInscrieri.cautarePers(1),1) 
        self.assertEqual(self.__repoInscrieri.cautarePers(33),0) 
        self.assertEqual(self.__repoInscrieri.cautarePers(3),1) 
        self.assertEqual(self.__repoInscrieri.cautarePers(65),0) 
    
    def test_cautareEvent(self):
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,1),1) 
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,7),0) 
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,2),1) 
    
    if __name__ == '__main__':
        unittest.main()


class TestService(unittest.TestCase):
    #white box test
    def setUp(self):
        self.__repoEvent = RepoEvent()
        self.__repoPers = RepoPers()
        self.__validareEvent = ValidatorEvent()
        self.__validarePers = ValidatorPers()
        self.__repoInscrieri = RepoInscrieri()
        self.__serviceEvent = ServiceEvent(self.__validareEvent,self.__repoEvent, self.__repoInscrieri)
        self.__servicePers = ServicePers(self.__validarePers, self.__repoPers, self.__repoInscrieri)
        self.__serviceInscrieri = ServiceInscrieri(self.__repoInscrieri,self.__repoEvent,self.__repoPers)
        
        self.__repoEvent.add_Event(Evenimente(1,"2/1/2019","6:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(2,"25/12/2021","2:0","Vine Craciunul"))
        self.__repoEvent.add_Event(Evenimente(3,"1/1/2021","7:30","Revelion"))
        self.__repoEvent.add_Event(Evenimente(4,"7/7/2021","1:30","Spectacol Special"))
        self.__repoEvent.add_Event(Evenimente(5,"25/12/2021","2:10","Festival mancare"))
        self.__repoEvent.add_Event(Evenimente(888,"2/12/2029","1:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(121,"33/9/2033","2:00","New Untold"))
        self.__repoEvent.add_Event(Evenimente(77,"2/8/2021","2:30","Magic Untold music festival"))
        self.__repoEvent.add_Event(Evenimente(33,"2/3/2020","7:30","Untold festival"))
        
        self.__repoPers.add_Pers(Persoane(1,"Berendi Razvan","Rucar 9"))
        self.__repoPers.add_Pers(Persoane(2,"Pop Maria","Lalele 12"))
        self.__repoPers.add_Pers(Persoane(3,"Cristea alex","Plopilor 10"))
        self.__repoPers.add_Pers(Persoane(4,"Muntean Cristian","Frunzisului 3"))
        
        self.__repoInscrieri.newPers(1)
        self.__repoInscrieri.addEvent(1, 2)
        self.__repoInscrieri.addEvent(1, 1)
        self.__repoInscrieri.addEvent(1, 5)
        self.__repoInscrieri.addEvent(1, 121)
        self.__repoInscrieri.newPers(3)
        self.__repoInscrieri.addEvent(3, 2)
        self.__repoInscrieri.addEvent(3, 1)
        self.__repoInscrieri.addEvent(3, 121)
        self.__repoInscrieri.newPers(2)
        self.__repoInscrieri.addEvent(2, 1)
        self.__repoInscrieri.newPers(4)
        self.__repoInscrieri.addEvent(4, 1)
        self.__repoInscrieri.addEvent(4, 2)
        self.__repoInscrieri.addEvent(4, 5)
        self.__repoInscrieri.addEvent(4, 3)
    
    def tearDown(self):
        unittest.TestCase.tearDown(self)
        
    
    def test_service_getALL_Events(self):
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[0].get_id(), 1)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[1].get_id(), 2)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[2].get_id(), 3)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[3].get_id(), 4)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[4].get_id(), 5)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[5].get_id(), 888)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[6].get_id(), 121)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[7].get_id(), 77)
        self.assertEqual( self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
    
    def test_service_adaugareEvent(self):
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("50", "2/2/2020", "1:30", "descriere"),1)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[9].get_id(), 50)
        
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("", "", "", ""),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("1", "2/2/2020", "1:30", "descriere"),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("73", "2/22/2020", "1:30", "descriere"),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("89", "2/2/2020", "1:80", "descriere"),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_adaugareEvent("dsd", "2/2/2020", "1:30", "descriere"),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),10)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[8].get_id(), 33)
        
    
    def test_service_stregereEvent(self):
        self.assertEqual(self.__serviceEvent.service_stregereEvent("1"),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),8)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[7].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_stregereEvent("44"),1)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),8)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[7].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_stregereEvent(""),2)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),8)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[7].get_id(), 33)
        
        self.assertEqual(self.__serviceEvent.service_stregereEvent("fafafas"),2)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),8)
        self.assertEqual(self.__serviceEvent.service_getALL_Events()[7].get_id(), 33)
    
    def test_service_modificareEvent(self):
        self.assertEqual(self.__serviceEvent.service_modificareEvent("1", "2/2/2020", "1:30", "descriere"),1)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("1", "2/2/2020", "9:30", "descriere"),1)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("50", "2/2/2020", "1:30", "descriere"),0)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("", "", "", ""),0)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("fsd", "2/2/2020", "1:30", "descriere"),0)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("999", "3112/77/2020", "1:30", "descriere"),0)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("999", "2/2/2020", "1:980", "descriere"),0)
        self.assertEqual(self.__serviceEvent.service_modificareEvent("999", "2/2/2020", "1:30", ""),0)
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        
    
    def test_service_cautareEvent(self):
        self.assertEqual(self.__serviceEvent.service_cautareEvent("0"),0)
        self.assertEqual(self.__serviceEvent.service_cautareEvent("-3"),0)
        self.assertEqual(self.__serviceEvent.service_cautareEvent("fasda"),0)
        self.assertEqual(self.__serviceEvent.service_cautareEvent(" "),0)
        self.assertEqual(self.__serviceEvent.service_cautareEvent(""),0)
        self.assertEqual(self.__serviceEvent.service_cautareEvent("1"),self.__serviceEvent.service_getALL_Events()[0])
        self.assertEqual(self.__serviceEvent.service_cautareEvent("33"),self.__serviceEvent.service_getALL_Events()[8])
    
    def test_generare_random_Event(self):
        self.__serviceEvent.generare_random_Event("0")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.__serviceEvent.generare_random_Event("-3")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.__serviceEvent.generare_random_Event("rasdfas")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.__serviceEvent.generare_random_Event(" ")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.__serviceEvent.generare_random_Event("")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),9)
        self.__serviceEvent.generare_random_Event("10")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),19)
        self.__serviceEvent.generare_random_Event("151")
        self.assertEqual(len(self.__serviceEvent.service_getALL_Events()),170)


    
    def test_service_getALL_Pers(self):
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.assertEqual( self.__servicePers.service_getALL_Pers()[0].get_persID(), 1)
        self.assertEqual( self.__servicePers.service_getALL_Pers()[1].get_persID(), 2)
        self.assertEqual( self.__servicePers.service_getALL_Pers()[2].get_persID(), 3)
        self.assertEqual( self.__servicePers.service_getALL_Pers()[3].get_persID(), 4)
    
    def test_service_adaugarePers(self):
        self.assertEqual(self.__servicePers.service_adaugarePers("50", "A B", "S 1"),1)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("", "", ""),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("1", "r a", "a 2"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("", "re re", "re 3"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("re", "re re", "re 3"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("55", "re", "re 4"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
        self.assertEqual(self.__servicePers.service_adaugarePers("77", "fd fd", "f12"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),5)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[4].get_persID(), 50)
        
    
    def test_service_stregerePers(self):
        self.assertEqual(self.__servicePers.service_stregerePers("1"),0)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)
        
        self.assertEqual(self.__servicePers.service_stregerePers("-4351"),1)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)
        
        self.assertEqual(self.__servicePers.service_stregerePers("351"),1)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)
        
        self.assertEqual(self.__servicePers.service_stregerePers(" "),2)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)
        
        self.assertEqual(self.__servicePers.service_stregerePers(""),2)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)
        
        self.assertEqual(self.__servicePers.service_stregerePers("fsdfsd"),2)
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),3)
        self.assertEqual(self.__servicePers.service_getALL_Pers()[2].get_persID(), 4)

    
    def test_service_modificarePers(self):
        self.assertEqual(self.__servicePers.service_modificarePers("1", "AAA a", "s 3"),1)
        self.assertEqual(self.__servicePers.service_modificarePers("1", "bbb a", "s 5"),1)
        self.assertEqual(self.__servicePers.service_modificarePers("", "", ""),0)
        self.assertEqual(self.__servicePers.service_modificarePers("32432", "AAA a", "s 3"),0)
        self.assertEqual(self.__servicePers.service_modificarePers("-1", "AAA a", "s 3"),0)
        self.assertEqual(self.__servicePers.service_modificarePers("dadfs fd", "AAA a", "s 3"),0)
        self.assertEqual(self.__servicePers.service_modificarePers("1", "bbba", "s 5"),0)
        self.assertEqual(self.__servicePers.service_modificarePers("1", "bbb a", "s5"),0)
        self.assertEqual(self.__servicePers.service_modificarePers("1", "bbb a 8756", "s5"),0)
        
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
    
    def test_service_cautarePersNUME(self):
        self.assertEqual(self.__servicePers.service_cautarePersNUME("0"),0)
        self.assertEqual(self.__servicePers.service_cautarePersNUME("ds ds ds"),0)
        self.assertEqual(self.__servicePers.service_cautarePersNUME("fasda"),0)
        self.assertEqual(self.__servicePers.service_cautarePersNUME(" "),0)
        self.assertEqual(self.__servicePers.service_cautarePersNUME(""),0)
        self.assertEqual(self.__servicePers.service_cautarePersNUME("Berendi Razvan")[0],self.__servicePers.service_getALL_Pers()[0])
        self.assertEqual(self.__servicePers.service_cautarePersNUME("MuntEan crIstiAn")[0],self.__servicePers.service_getALL_Pers()[3])
    
    def test_service_cautarePersID(self):
        self.assertEqual(self.__servicePers.service_cautarePersID("0"),0)
        self.assertEqual(self.__servicePers.service_cautarePersID("ds ds ds"),0)
        self.assertEqual(self.__servicePers.service_cautarePersID("-3"),0)
        self.assertEqual(self.__servicePers.service_cautarePersID(" "),0)
        self.assertEqual(self.__servicePers.service_cautarePersID(""),0)
        self.assertEqual(self.__servicePers.service_cautarePersID("1"),self.__servicePers.service_getALL_Pers()[0])
        self.assertEqual(self.__servicePers.service_cautarePersID("4"),self.__servicePers.service_getALL_Pers()[3])
    
    
    def test_generare_random_Pers(self):
        self.__servicePers.generare_random_Pers("0")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.__servicePers.generare_random_Pers("-3")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.__servicePers.generare_random_Pers("rasdfas")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.__servicePers.generare_random_Pers(" ")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.__servicePers.generare_random_Pers("")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),4)
        self.__servicePers.generare_random_Pers("10")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),14)
        self.__servicePers.generare_random_Pers("151")
        self.assertEqual(len(self.__servicePers.service_getALL_Pers()),165)

    
    def test_service_getAll_Inscrieri(self):
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        
    
    def test_service_InscrierePersEvent(self):
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("1","5"),2)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("7","1"),3)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("7","7"),3)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("1","7"),3)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("1","3"),0)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121, 3], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("4","4"),0)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121,3], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3, 4]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("",""),1)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121,3], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3, 4]})
        self.assertEqual(self.__serviceInscrieri.service_InscrierePersEvent("6fds","das"),1)
        self.assertEqual(self.__serviceInscrieri.service_getAll_Inscrieri(),{1: [2, 1, 5, 121,3], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3, 4]})
    
    
    def test_service_raport1(self):
        serv=self.__serviceInscrieri.service_raport1("1")
        self.assertEqual(serv,[5, 121, 1, 2])
        
        serv=self.__serviceInscrieri.service_raport1("")
        self.assertEqual(serv,-1)
        
        serv=self.__serviceInscrieri.service_raport1("Cristiano Ronaldo")
        self.assertEqual(serv,-1)
        
        serv=self.__serviceInscrieri.service_raport1("125312")
        self.assertEqual(serv,0)
    
    
    def test_service_raport2(self):
        serv=self.__serviceInscrieri.service_raport2("2")
        self.assertEqual(len(serv),2)
        self.assertEqual( serv[0].get_key(),1)
        self.assertEqual( serv[0].get_contor(),4)
        self.assertEqual( serv[1].get_key(),4)
        self.assertEqual( serv[1].get_contor(),4)
        
        serv=self.__serviceInscrieri.service_raport2("10")
        self.assertEqual(serv,0)
        
        serv=self.__serviceInscrieri.service_raport2("das")
        self.assertEqual(serv,-1)
        
    
    def test_service_raport3(self):
        serv=self.__serviceInscrieri.service_raport3()
        self.assertEqual(len(serv),1)
        self.assertEqual(serv[0].get_key(),1)
        self.assertEqual(serv[0].get_contor(),4)
        
        rE = RepoEvent()
        rP = RepoPers()
        rI = RepoInscrieri()
        sI = ServiceInscrieri(rI,rE,rP)
        serv=sI.service_raport3()
        self.assertEqual( serv,[])
    
    def test_service_raport_lab(self):
        serv=self.__serviceInscrieri.service_raport_lab("Untold")
        self.assertEqual(serv,[1, 3, 2, 4])
        
        serv=self.__serviceInscrieri.service_raport_lab("Festival mancare")
        self.assertEqual(serv,[1, 4])
        
        serv=self.__serviceInscrieri.service_raport_lab("facultate")
        self.assertEqual(serv,[])
    
    
    def test_ordonareRez(self):
        x=[DTO_Rapoarte(1,1),DTO_Rapoarte(2,9),DTO_Rapoarte(3,8),DTO_Rapoarte(5,0)]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(x[3].get_key(),5)
        self.assertEqual(x[3].get_contor(),0)
        self.assertEqual(x[2].get_key(),1)
        self.assertEqual(x[2].get_contor(),1)
        self.assertEqual(x[1].get_key(),3)
        self.assertEqual(x[1].get_contor(),8)
        self.assertEqual(x[0].get_key(),2)
        self.assertEqual(x[0].get_contor(),9)
        
        x=[DTO_Rapoarte(1,1),DTO_Rapoarte(2,1),DTO_Rapoarte(3,2),DTO_Rapoarte(4,2)]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(x[3].get_key(),2)
        self.assertEqual(x[3].get_contor(),1)
        self.assertEqual(x[2].get_key(),1)
        self.assertEqual(x[2].get_contor(),1)
        self.assertEqual(x[1].get_key(),4)
        self.assertEqual(x[1].get_contor(),2)
        self.assertEqual(x[0].get_key(),3)
        self.assertEqual(x[0].get_contor(),2)
        
        
        x=[DTO_Rapoarte(1,-1),DTO_Rapoarte(2,-9),DTO_Rapoarte(3,-7)]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(x[0].get_key(),1)
        self.assertEqual(x[0].get_contor(),-1)
        self.assertEqual(x[1].get_key(),3)
        self.assertEqual(x[1].get_contor(),-7)
        self.assertEqual(x[2].get_key(),2)
        self.assertEqual(x[2].get_contor(),-9)
        
        x=[DTO_Rapoarte(1,-1)]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(x[0].get_key(),1)
        self.assertEqual(x[0].get_contor(),-1)
        
        x=[DTO_Rapoarte(1,0)]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(x[0].get_key(),1)
        self.assertEqual(x[0].get_contor(),0)

        x=[]
        self.__serviceInscrieri.ordonareRez(x)
        self.assertEqual(len(x),0)
        self.assertEqual(x,[])
    
    
    def test_ordonare(self):
        x=[1,2,3,4,5]
        self.__serviceInscrieri.ordonare(x, self.__serviceEvent.service_getALL_Events())
        self.assertEqual(x, [5, 3, 4, 1, 2] )
        
        x=[]
        self.__serviceInscrieri.ordonare(x, self.__serviceEvent.service_getALL_Events())
        self.assertEqual(x, [] )
        
        x=[1,2]
        self.__serviceInscrieri.ordonare(x, self.__serviceEvent.service_getALL_Events())
        self.assertEqual(x, [1,2] )
        
        x=[2]
        self.__serviceInscrieri.ordonare(x, self.__serviceEvent.service_getALL_Events())
        self.assertEqual(x, [2] )

    if __name__ == '__main__':
        unittest.main()        


class TestRepoFIS(unittest.TestCase):
    
    def setUp(self):
        
        with open('testeEvent.txt','w'):pass
        with open('testePers.txt','w'):pass
        with open('testeInscrieri.txt','w'):pass
            
        self.__repoEvent=RepoEventFIS('testeEvent.txt')
        self.__repoPers=RepoPersFIS('testePers.txt')
        self.__repoInscrieri=RepoInscrieriFIS('testeInscrieri.txt')
        
        self.__repoEvent.add_Event(Evenimente(1,"2/1/2019","6:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(2,"25/12/2021","2:0","Vine Craciunul"))
        self.__repoEvent.add_Event(Evenimente(3,"1/1/2021","7:30","Revelion"))
        self.__repoEvent.add_Event(Evenimente(4,"7/7/2021","1:30","Spectacol Special"))
        self.__repoEvent.add_Event(Evenimente(5,"25/12/2021","2:10","Festival mancare"))
        self.__repoEvent.add_Event(Evenimente(888,"2/12/2029","1:30","Untold"))
        self.__repoEvent.add_Event(Evenimente(121,"33/9/2033","2:00","New Untold"))
        self.__repoEvent.add_Event(Evenimente(77,"2/8/2021","2:30","Magic Untold music festival"))
        self.__repoEvent.add_Event(Evenimente(33,"2/3/2020","7:30","Untold festival"))
        
        self.__repoPers.add_Pers(Persoane(1,"Berendi Razvan","Rucar 9"))
        self.__repoPers.add_Pers(Persoane(2,"Pop Maria","Lalele 12"))
        self.__repoPers.add_Pers(Persoane(3,"Cristea alex","Plopilor 10"))
        self.__repoPers.add_Pers(Persoane(4,"Muntean Cristian","Frunzisului 3"))
        
        self.__repoInscrieri.newPers(1)
        self.__repoInscrieri.addEvent(1, 2)
        self.__repoInscrieri.addEvent(1, 1)
        self.__repoInscrieri.addEvent(1, 5)
        self.__repoInscrieri.addEvent(1, 121)
        self.__repoInscrieri.newPers(3)
        self.__repoInscrieri.addEvent(3, 2)
        self.__repoInscrieri.addEvent(3, 1)
        self.__repoInscrieri.addEvent(3, 121)
        self.__repoInscrieri.newPers(2)
        self.__repoInscrieri.addEvent(2, 1)
        self.__repoInscrieri.newPers(4)
        self.__repoInscrieri.addEvent(4, 1)
        self.__repoInscrieri.addEvent(4, 2)
        self.__repoInscrieri.addEvent(4, 5)
        self.__repoInscrieri.addEvent(4, 3)
        
    
    def tearDown(self):
        with open('testeEvent.txt',"w"):pass
        with open('testePers.txt',"w"):pass
        with open('testeInscrieri.txt',"w"):pass
        
    def test_get_AllEvents(self):
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),9)
        self.assertEqual( self.__repoEvent.get_AllEvents()[0].get_id(), 1)
        self.assertEqual( self.__repoEvent.get_AllEvents()[1].get_id(), 2)
        self.assertEqual( self.__repoEvent.get_AllEvents()[2].get_id(), 3)
        self.assertEqual( self.__repoEvent.get_AllEvents()[3].get_id(), 4)
        self.assertEqual( self.__repoEvent.get_AllEvents()[4].get_id(), 5)
        self.assertEqual( self.__repoEvent.get_AllEvents()[5].get_id(), 888)
        self.assertEqual( self.__repoEvent.get_AllEvents()[6].get_id(), 121)
        self.assertEqual( self.__repoEvent.get_AllEvents()[7].get_id(), 77)
        self.assertEqual( self.__repoEvent.get_AllEvents()[8].get_id(), 33)

    
    def test_add_Event(self):
        self.__repoEvent.add_Event(Evenimente(13,"2/3/2029","1:30","Super"))
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),10)
        self.assertEqual( self.__repoEvent.get_AllEvents()[9].get_id(), 13)
    
    def test_remove_Event(self):
        self.__repoEvent.remove_Event(2)
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),8)
        self.assertEqual( self.__repoEvent.get_AllEvents()[1].get_id(), 3)
        
            
    def test_modificare_Event(self):
        self.__repoEvent.modificare_Event(2,"2/2/2010","1:15","AAAA")
        self.assertEqual(len(self.__repoEvent.get_AllEvents()),9)
        self.assertEqual(str(self.__repoEvent.get_AllEvents()[1]), "2. Data: 2/2/2010; Durata: 1 ore si 15 minute; Descrierea: AAAA")
        
        
    def test_cautare_Event(self):
        ok=self.__repoEvent.cautare_Event(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoEvent.get_AllEvents()[1])
        ok=self.__repoEvent.cautare_Event(34)
        self.assertEqual(ok,0)
        
    def test_get_AllPers(self):
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual( self.__repoPers.get_AllPers()[0].get_persID(), 1)
        self.assertEqual( self.__repoPers.get_AllPers()[1].get_persID(), 2)
        self.assertEqual( self.__repoPers.get_AllPers()[2].get_persID(), 3)
        self.assertEqual( self.__repoPers.get_AllPers()[3].get_persID(), 4)
        
    def test_add_Pers(self):
        self.__repoPers.add_Pers(Persoane(10,"AAA BBB","ADR 30"))
        self.assertEqual(len(self.__repoPers.get_AllPers()),5)
        self.assertEqual( self.__repoPers.get_AllPers()[4].get_persID(), 10)
        
    def test_remove_Pers(self):
        self.__repoPers.remove_Pers(2)
        self.assertEqual(len(self.__repoPers.get_AllPers()),3)
        self.assertEqual( self.__repoPers.get_AllPers()[1].get_persID(), 3)
        
    def test_modificare_Pers(self):
        self.__repoPers.modificare_Pers(2,"AAA BBB","AA 2")
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual(str(self.__repoPers.get_AllPers()[1]), "2. Nume si prenume: AAA BBB; Adresa: Strada AA nr.2")
        
    def test_modificare_Pers_rec(self):
        self.__repoPers.modificare_Pers_rec(2,"AAA BBB","AA 2")
        self.assertEqual(len(self.__repoPers.get_AllPers()),4)
        self.assertEqual(str(self.__repoPers.get_AllPers()[1]), "2. Nume si prenume: AAA BBB; Adresa: Strada AA nr.2")
    
    
    
    def test_cautare_Pers_ID(self):
        ok=self.__repoPers.cautare_Pers_ID(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoPers.get_AllPers()[1])
        ok=self.__repoPers.cautare_Pers_ID(34)
        self.assertEqual(ok,0)
        
    def test_cautare_Pers_ID_rec(self):
        ok=self.__repoPers.cautare_Pers_ID_rec(2)
        self.assertNotEqual(ok,0)
        self.assertEqual(ok,self.__repoPers.get_AllPers()[1])
        ok=self.__repoPers.cautare_Pers_ID_rec(34)
        self.assertEqual(ok,0)
      
      
        
    def test_cautare_Pers_NUME(self):
        ok=self.__repoPers.cautare_Pers_NUME(Nume("BERENDI RAZVAN"))
        self.assertNotEqual(ok,0)
        self.assertEqual(ok[0],self.__repoPers.get_AllPers()[0])
        ok=self.__repoPers.cautare_Pers_NUME(Nume("Ananas mic"))
        self.assertEqual(ok,0)   
    

    def test_getAll_INSCRIERI(self):  
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
    
    def test_newPers(self):
        self.__repoInscrieri.newPers(10)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3], 10: []})

    def test_addEvent(self):
        self.__repoInscrieri.addEvent(2,3)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1,3], 4: [1, 2, 5, 3]})
 
    def test_removeEvent(self):
        self.__repoInscrieri.removeEvent(1)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5, 121], 3: [2, 121], 4: [ 2, 5, 3]})
        self.__repoInscrieri.removeEvent(7)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5, 121], 3: [2, 121], 4: [ 2, 5, 3]})
        self.__repoInscrieri.removeEvent(121)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 5], 3: [2], 4: [ 2, 5, 3]})
 
    
    def test_removePersFaraInscrieri(self):
        self.__repoInscrieri.newPers(10)
        self.__repoInscrieri.newPers(12)
        self.__repoInscrieri.newPers(11)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3], 10: [], 12: [], 11: []})
        self.__repoInscrieri.removePersFaraInscrieri()
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{1: [2, 1, 5, 121], 3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
           
    def test_removePers(self):
        self.__repoInscrieri.removePers(1)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(10)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 2: [1], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(2)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{3: [2, 1, 121], 4: [1, 2, 5, 3]})
        self.__repoInscrieri.removePers(3)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{4: [1, 2, 5, 3]})     
        self.__repoInscrieri.removePers(4)
        self.assertEqual(self.__repoInscrieri.getAll_INSCRIERI(),{})    
          
    
    def test_cautarePers(self):
        self.assertEqual(self.__repoInscrieri.cautarePers(1),1) 
        self.assertEqual(self.__repoInscrieri.cautarePers(33),0) 
        self.assertEqual(self.__repoInscrieri.cautarePers(3),1) 
        self.assertEqual(self.__repoInscrieri.cautarePers(65),0) 
    
    def test_cautareEvent(self):
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,1),1) 
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,7),0) 
        self.assertEqual(self.__repoInscrieri.cautareEvent(1,2),1) 

    if __name__ == '__main__':
        unittest.main()
