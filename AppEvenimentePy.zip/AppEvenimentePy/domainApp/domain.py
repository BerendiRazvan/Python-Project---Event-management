class DTO_Rapoarte:
    """
    DTO-ul pt rapoarte
    """
    def __init__(self,key,contor):
        self.__key=key
        self.__contor=contor
        
    def get_key(self):
        """
        Ghetter:Returneaza cheie
        """
        return self.__key
    
    def get_contor(self):
        """
        Ghetter:Returneaza contor
        """
        return self.__contor
    
    def set_key(self,key_code):
        """
        Setter:Modifica cheie
        """
        self.__key=key_code
        
    def set_contor(self,contor_value):
        """
        Setter:Modifica cheie
        """
        self.__contor=contor_value
    
class Data:
    """
    Clasa pentru Data
    Data: <zi>, <luna>, <an>
    """
     
    def __init__(self,data):
        """
        INIT:
        input -sir de caractere de forma zz/ll/aaaa
        <zi> -sir de caractere
        <luna> -sir de caractere
        <an> -sir de caractere
        """
        data=data.upper()
        data=data.split('/')
        self.__zi=data[0]
        self.__luna=data[1]
        self.__an=data[2]
    
    def get_zi(self):
        """
        Getter:Returneaza ziua
        """
        return self.__zi
    
    def set_zi(self,zi):
        """
        Setter:Modifica ziua
        """
        self.__zi=zi
        
    def get_luna(self):
        """
        Getter:Returneaza luna
        """
        return self.__luna
    
    def set_luna(self,luna):
        """
        Setter:Modifica luna
        """
        self.__luna=luna
        
    def get_an(self):
        """
        Getter:Returneaza anul
        """
        return self.__an
    
    def set_an(self,an):
        """
        Setter:Modifica anul
        """
        self.__an=an
        
    def __str__(self):
        """
        STR:
        Returneaza data sub forma: self.__zi+"/"+self.__luna+"/"+self.__an
        """
        return self.__zi+"/"+self.__luna+"/"+self.__an
        
        

class Timp:
    """
    Clasa pentru Timp
    Timp: <ore>, <minute>
    """
    
    def __init__(self, timp):
        """
        INIT:
        input -sir de caractere de forma hh:mm
        <ore> -sir de caractere
        <minute> -sir de caractere
        """
        timp=timp.split(':')
        self.__ore=timp[0]
        self.__minu=timp[1]
    
    def get_ore(self):
        """
        Getter:Returneaza orele
        """
        return self.__ore
    
    def set_ore(self,ore):
        """
        Setter:Modifica ora
        """
        self.__ore=ore
        
    def get_min(self):
        """
        Getter:Returneaza minutele
        """
        return self.__minu
    
    def set_min(self,minu):
        """
        Setter:Modifica minutele
        """
        self.__minu=minu
        
    def __str__(self):
        """
        STR:
        Returneaza timpul sub forma: self.__ore+" ore si "+self.__minu+" minute"
        """
        return self.__ore+" ore si "+self.__minu+" minute"

class Evenimente:
    """
    Clasa pentru Evenimente
    Evenimente: <ID>, <dată>, <timp>, <descriere>
    """
    
    def __init__(self,ID,data,timp,descriere):
        """
        INIT:
        input -sir de caractere de forma: id data timp descriere
        <ID> -numar natural
        <dată> -Data
        <timp> -Timp
        <descriere> -sir de caractere
        """
        self.__ID = int(ID)
        self.__data = Data(data)
        self.__timp = Timp(timp)
        self.__descriere = descriere.upper()
        
    def __eq__(self,eveniment):
        if str(eveniment).isalpha():
            return False
        if str(eveniment).isdigit():
            return False
        return self.get_id()==eveniment.get_id()
    
    def __str__(self):
        """
        STR:
        Returneaza evenimentul sub forma: str(self.__ID)+". Data: "+str(self.__data)+"; Durata: "+str(self.__timp)+"; Descrierea: "+self.__descriere
        """
        return str(self.__ID)+". Data: "+str(self.__data)+"; Durata: "+str(self.__timp)+"; Descrierea: "+self.__descriere

    def get_id(self):
        """
        Getter:Returneaza ID
        """
        return self.__ID
    
    def set_id(self,ID):
        """
        Setter:Modifica ID
        """
        self.__ID=ID
    
    def get_data(self):
        """
        Getter:Returneaza data
        """
        return self.__data
    
    def set_data(self,data):
        """
        Setter:Modifica Data
        """
        self.__data=Data(data)
    
    def get_timp(self):
        """
        Getter:Returneaza timpul
        """
        return self.__timp
    
    def set_timp(self,timp):
        """
        Setter:Modifica Timpul
        """
        self.__timp=Timp(timp)
    
    def get_descriere(self):
        """
        Getter:Returneaza descrierea
        """
        return self.__descriere
    
    def set_descriere(self,descriere):
        """
        Setter:Modifica descrierea
        """
        self.__descriere=descriere.upper()


class Nume:
    """
    Clasa pentru Nume
    Nume: <nume>, <prenume>
    """
    
    def __init__(self, nume):
        """
        INIT:
        input -sir de caractere de forma: nume prenume
        <nume> -sir de caractere
        <prenume> -sir de caractere
        """
        nume=nume.upper()
        nume=nume.split(" ")
        self.__numele=nume[0]
        self.__prenumele=nume[1]
    
    def get_nume(self):
        """
        Getter:Returneaza numele
        """
        return self.__numele
    
    def set_nume(self,numele):
        """
        Setter:Modifica numele
        """
        self.__numele=numele.upper()
        
    def get_prenume(self):
        """
        Getter:Returneaza prenumele
        """
        return self.__prenumele
    
    def set_prenume(self,prenumele):
        """
        Setter:Modifica prenumele
        """
        self.__prenumele=prenumele.upper()
        
    def __str__(self):
        """
        STR:
        Returneaza numele sub forma: self.__numele+" "+self.__prenumele
        """
        return  self.__numele+" "+self.__prenumele

class Adresa:
    """
    Clasa pentru Adresa
    Adresa: <strada>, <nrStrada>
    """
    def __init__(self, adr):
        """
        INIT:
        input -sir de caractere de forma: strada numar
        <strada> -sir de caractere 
        <nrStrada> -sir de caractere
        """
        adr=adr.upper()
        adr=adr.split(" ")
        self.__strada=adr[0]
        self.__nr=adr[1]
    
    def get_strada(self):
        """
        Getter:Returneaza strada
        """
        return self.__strada
    
    def set_strada(self,strada):
        """
        Setter:Modifica strada
        """
        self.__strada=strada.upper()
        
    def get_nrStrada(self):
        """
        Getter:Returneaza nr. strada
        """
        return self.__nr
    
    def set_nrStrada(self,nr):
        """
        Setter:Modifica nr. strada
        """
        self.__nr=nr
        
    def __str__(self):
        """
        STR:
        Returneaza adresa sub forma: "Strada "+self.__strada+" nr."+str(self.__nr)
        """
        return "Strada "+self.__strada+" nr."+str(self.__nr)
    

class Persoane:
    """
    Clasa pentru Persoane
    Persoane: <persID>, <nume>, <adresă>
    """
    
    def __init__(self,persID,nume,adr):
        """
        INIT:
        input -sir de caractere de forma: id nume adresa 
        <persID> -numar natural
        <nume> -Nume
        <adresa> -Adresa
        """
        self.__persID = int(persID)
        self.__nume = Nume(nume)
        self.__adresa = Adresa(adr)
        
    def __eq__(self,persoana):
        if str(persoana).isalpha():
            return False
        if str(persoana).isdigit():
            return False
        return self.get_persID()==persoana.get_persID()
    
    def __str__(self):
        """
        STR:
        Returneaza persoana sub forma: str(self.__persID)+". Nume si prenume: "+str(self.__nume)+"; Adresa: "+str(self.__adresa)
        """
        return str(self.__persID)+". Nume si prenume: "+str(self.__nume)+"; Adresa: "+str(self.__adresa)
    
        
    def get_persID(self):
        """
        Getter:Returneaza ID
        """
        return self.__persID
    
    def set_id(self,persID):
        """
        Setter:Modifica ID
        """
        self.__persID=persID
    
    def get_nume(self):
        """
        Getter:Returneaza numele
        """
        return self.__nume
    
    def set_nume(self,nume):
        """
        Setter:Modifica Nume
        """
        self.__nume=Nume(nume)
    
    def get_adresa(self):
        """
        Getter:Returneaza adresa
        """
        return self.__adresa
    
    def set_adresa(self,adresa):
        """
        Setter:Modifica Adresa
        """
        self.__adresa=Adresa(adresa)
